/*
  CampusNav Premium Frontend v8 — Clean Road-Style Corridors + 90° Clockwise Map
  ---------------------------------
  Designed for the tested FastAPI backend at http://127.0.0.1:8000.

  Key UI rules:
  - The original NAV nodes/edges are hidden from users.
  - Only the active route is drawn.
  - Checkpoint dots on the route are the indoor position controls.
  - Completed route sections disappear after a checkpoint is confirmed.
  - Route geometry comes from the backend. Only tiny <= ~1.5 px visual jitter
    is simplified; meaningful corners are preserved to avoid wall shortcuts.
  - The complete visual map (blueprint + active route + checkpoint controls) is
    displayed 90° clockwise in the frontend only. SVG files, database coordinates,
    graph geometry, and backend routing are not modified.
*/

const API_BASE = "http://127.0.0.1:8000";
const INKSCAPE_NS = "http://www.inkscape.org/namespaces/inkscape";
const SVG_NS = "http://www.w3.org/2000/svg";

// Visual-only corridor settings.
// These DO NOT change A*, the database, SVG coordinates, or route calculation.
// The permanent corridor "road" is reconstructed from the floor's NAV edge
// centerlines, while room-door connector spurs are deliberately excluded.
const CORRIDOR_VISUAL_WIDTH_UNITS = 24;
const CORRIDOR_VISUAL_BORDER_UNITS = 28;
const CORRIDOR_NODE_MATCH_TOLERANCE = 4.0;

const state = {
  floors: [],
  maps: new Map(),
  entrances: [],
  locations: [],
  locationsByFloor: new Map(),
  selectedStart: null,
  selectedDestination: null,
  route: null,
  lastPlan: null,
  blocked: new Set(),
  currentCheckpointIndex: 0,
  selectedFloor: "G",
  floorRouteIndexes: {},
  currentSvg: null,
  originalViewBox: null,
  viewBox: null,
  dragging: false,
  dragStart: null,
  suggestionItems: { start: [], destination: [] },
  sourceViewBox: null,
  rotationGroup: null,
};

const $ = (id) => document.getElementById(id);
const els = {
  apiPill: $("apiPill"),
  gpsBtn: $("gpsBtn"),
  startSearch: $("startSearch"),
  startSuggestions: $("startSuggestions"),
  startSelection: $("startSelection"),
  clearStartBtn: $("clearStartBtn"),
  destinationSearch: $("destinationSearch"),
  destinationSuggestions: $("destinationSuggestions"),
  clearDestinationBtn: $("clearDestinationBtn"),
  exitChooser: $("exitChooser"),
  exitButtons: $("exitButtons"),
  navigateBtn: $("navigateBtn"),
  formMessage: $("formMessage"),
  routeSummary: $("routeSummary"),
  summaryRouteText: $("summaryRouteText"),
  summaryMode: $("summaryMode"),
  summaryCost: $("summaryCost"),
  summaryFloors: $("summaryFloors"),
  progressPercent: $("progressPercent"),
  progressFill: $("progressFill"),
  currentLandmark: $("currentLandmark"),
  remainingText: $("remainingText"),
  clearRouteBtn: $("clearRouteBtn"),
  currentFloorTitle: $("currentFloorTitle"),
  floorButtons: $("floorButtons"),
  zoomOutBtn: $("zoomOutBtn"),
  zoomInBtn: $("zoomInBtn"),
  fitBtn: $("fitBtn"),
  mapViewport: $("mapViewport"),
  mapLoading: $("mapLoading"),
  svgHost: $("svgHost"),
  floatingNavControls: $("floatingNavControls"),
  previousCheckpointBtn: $("previousCheckpointBtn"),
  centerMeBtn: $("centerMeBtn"),
  stepBar: $("stepBar"),
  nextStepTitle: $("nextStepTitle"),
  nextStepSubtitle: $("nextStepSubtitle"),
  reportBlockedBtn: $("reportBlockedBtn"),
  currentStepCard: $("currentStepCard"),
  currentStepTitle: $("currentStepTitle"),
  currentStepFloor: $("currentStepFloor"),
  routeInstructionsCard: $("routeInstructionsCard"),
  routeInstructions: $("routeInstructions"),
  instructionCount: $("instructionCount"),
  blockedDialog: $("blockedDialog"),
  applyBlockedBtn: $("applyBlockedBtn"),
  toast: $("toast"),
};

async function api(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, options);
  if (!response.ok) {
    let detail = `${response.status} ${response.statusText}`;
    try {
      const body = await response.json();
      detail = body.detail || detail;
    } catch (_) {}
    throw new Error(detail);
  }
  const contentType = response.headers.get("content-type") || "";
  return contentType.includes("application/json") ? response.json() : response.text();
}

async function boot() {
  bindEvents();
  try {
    const health = await api("/health");
    setApiStatus(true, `Online · ${health.floors} floors`);

    const [floors, maps, entrances] = await Promise.all([
      api("/floors"),
      api("/maps"),
      api("/entrances"),
    ]);

    state.floors = floors;
    state.entrances = entrances;
    maps.forEach((m) => state.maps.set(m.floor_id, m));

    const locationLists = await Promise.all(
      floors.map(async (f) => {
        const rows = await api(`/locations?floor_id=${encodeURIComponent(f.floor_id)}`);
        state.locationsByFloor.set(f.floor_id, rows);
        return rows;
      })
    );
    state.locations = locationLists.flat();

    renderExitChoices();
    renderFloorButtons();
    await loadFloorMap("G", true);
  } catch (error) {
    console.error(error);
    setApiStatus(false, "Backend offline");
    showFormError(
      "CampusNav could not connect to FastAPI. Start it with: python -m uvicorn backend.main:app --reload"
    );
  }
}

function bindEvents() {
  bindSmartSearch("start", els.startSearch, els.startSuggestions);
  bindSmartSearch("destination", els.destinationSearch, els.destinationSuggestions);

  els.clearStartBtn.addEventListener("click", () => clearSelection("start"));
  els.clearDestinationBtn.addEventListener("click", () => clearSelection("destination"));
  els.gpsBtn.addEventListener("click", useGps);
  els.navigateBtn.addEventListener("click", () => planRoute());
  els.clearRouteBtn.addEventListener("click", clearRoute);
  els.previousCheckpointBtn.addEventListener("click", previousCheckpoint);
  els.centerMeBtn.addEventListener("click", centerCurrentCheckpoint);
  els.zoomInBtn.addEventListener("click", () => zoomMap(0.82));
  els.zoomOutBtn.addEventListener("click", () => zoomMap(1.22));
  els.fitBtn.addEventListener("click", fitMap);

  els.mapViewport.addEventListener(
    "wheel",
    (event) => {
      event.preventDefault();
      zoomMap(event.deltaY < 0 ? 0.88 : 1.14, event.clientX, event.clientY);
    },
    { passive: false }
  );
  els.mapViewport.addEventListener("pointerdown", panStart);
  els.mapViewport.addEventListener("pointermove", panMove);
  els.mapViewport.addEventListener("pointerup", panEnd);
  els.mapViewport.addEventListener("pointercancel", panEnd);

  els.reportBlockedBtn.addEventListener("click", openBlockedDialog);
  els.applyBlockedBtn.addEventListener("click", (event) => {
    event.preventDefault();
    rerouteFromCurrentCheckpoint();
  });

  document.querySelectorAll(".avoid-buttons input").forEach((input) => {
    input.addEventListener("change", () => {
      if (input.checked) state.blocked.add(input.value);
      else state.blocked.delete(input.value);
    });
  });

  document.addEventListener("click", (event) => {
    if (!event.target.closest(".smart-search")) {
      hideSuggestions("start");
      hideSuggestions("destination");
    }
  });
}

function setApiStatus(ok, message) {
  els.apiPill.classList.toggle("online", ok);
  els.apiPill.classList.toggle("offline", !ok);
  els.apiPill.querySelector("span:last-child").textContent = message;
}

function showToast(message) {
  els.toast.textContent = message;
  els.toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => els.toast.classList.remove("show"), 2400);
}

function showFormError(message) {
  els.formMessage.hidden = false;
  els.formMessage.textContent = message;
}

function clearFormError() {
  els.formMessage.hidden = true;
  els.formMessage.textContent = "";
}

function selectedMode() {
  return document.querySelector('input[name="mode"]:checked')?.value || "lift";
}

function floorName(floorId) {
  return state.floors.find((f) => f.floor_id === floorId)?.name || floorId;
}

function humanize(value) {
  return String(value || "")
    .replaceAll("_", " ")
    .replace(/\b\w/g, (m) => m.toUpperCase());
}

function normalizeText(value) {
  return String(value || "").trim().toLowerCase();
}

function displayLocation(item) {
  const name = item.name && item.name !== item.code ? ` · ${item.name}` : "";
  return `${item.code}${name}`;
}

function locationIcon(type) {
  const t = normalizeText(type);
  if (/toilet|bathroom|washroom|wc/.test(t)) return "🚻";
  if (/lab/.test(t)) return "⚗";
  if (/faculty|office/.test(t)) return "▣";
  if (/entrance|exit/.test(t)) return "↗";
  return "□";
}

function bindSmartSearch(kind, input, suggestions) {
  input.addEventListener("input", () => {
    clearFormError();
    if (kind === "start") state.selectedStart = null;
    else state.selectedDestination = null;

    const query = input.value.trim();
    if (kind === "destination") {
      const wantsExit = /(^|\s)exit(\s|$)/i.test(query) || /^leave\b/i.test(query);
      els.exitChooser.hidden = !wantsExit;
      if (wantsExit) {
        hideSuggestions("destination");
        return;
      }
    }
    renderSuggestions(kind, query, suggestions);
  });

  input.addEventListener("focus", () => {
    const query = input.value.trim();
    if (kind === "destination" && /(^|\s)exit(\s|$)/i.test(query)) {
      els.exitChooser.hidden = false;
      return;
    }
    renderSuggestions(kind, query, suggestions);
  });
}

function renderSuggestions(kind, query, container) {
  const q = normalizeText(query);
  let pool = [...state.locations];

  if (kind === "start") {
    const entranceItems = state.entrances.map((e) => ({
      floor_id: "G",
      code: e.original_node_id,
      name: `${e.label} · Entrance`,
      type: "entrance",
      isEntrance: true,
    }));
    pool = [...entranceItems, ...pool];
  }

  let results = pool.filter((item) => {
    if (!q) return kind === "start" ? item.floor_id === "G" : false;
    const haystack = normalizeText(`${item.code} ${item.name || ""} ${item.type || ""} ${item.floor_id || ""}`);
    return haystack.includes(q);
  });

  results = results.slice(0, 12);
  state.suggestionItems[kind] = results;

  if (!results.length) {
    if (!q) {
      container.hidden = true;
      return;
    }
    container.innerHTML = `<div class="suggestion-empty">No matching location found.</div>`;
    container.hidden = false;
    return;
  }

  container.innerHTML = results
    .map(
      (item, index) => `
        <button class="suggestion-item" type="button" data-kind="${kind}" data-index="${index}">
          <span class="suggestion-icon">${escapeHtml(locationIcon(item.type))}</span>
          <span class="suggestion-copy">
            <strong>${escapeHtml(displayLocation(item))}</strong>
            <span>${escapeHtml(item.floor_id)} · ${escapeHtml(humanize(item.type || "location"))}</span>
          </span>
        </button>`
    )
    .join("");
  container.hidden = false;

  container.querySelectorAll(".suggestion-item").forEach((button) => {
    button.addEventListener("click", () => {
      const item = state.suggestionItems[kind][Number(button.dataset.index)];
      chooseLocation(kind, item);
    });
  });
}

function chooseLocation(kind, item) {
  if (!item) return;
  const selection = {
    kind: "location",
    floor_id: item.floor_id,
    code: item.code,
    name: item.name || item.code,
    type: item.type || "location",
  };

  if (kind === "start") {
    state.selectedStart = selection;
    els.startSearch.value = `${item.code} · ${floorName(item.floor_id)}`;
    els.startSelection.hidden = false;
    els.startSelection.textContent = `Start confirmed: ${item.code} on ${floorName(item.floor_id)}`;
    hideSuggestions("start");
  } else {
    state.selectedDestination = selection;
    els.destinationSearch.value = `${item.code} · ${floorName(item.floor_id)}`;
    els.exitChooser.hidden = true;
    hideSuggestions("destination");
  }
}

function clearSelection(kind) {
  if (kind === "start") {
    state.selectedStart = null;
    els.startSearch.value = "";
    els.startSelection.hidden = true;
    els.startSearch.focus();
  } else {
    state.selectedDestination = null;
    els.destinationSearch.value = "";
    els.exitChooser.hidden = true;
    renderExitChoices();
    els.destinationSearch.focus();
  }
}

function hideSuggestions(kind) {
  const el = kind === "start" ? els.startSuggestions : els.destinationSuggestions;
  el.hidden = true;
}

function renderExitChoices() {
  const options = [
    {
      mode: "nearest",
      code: "EXIT",
      label: "Nearest available exit",
      description: "CampusNav chooses the best exit for your current route.",
    },
    ...state.entrances.map((e) => ({
      mode: "specific",
      code: e.original_node_id,
      label: `${e.label} / Exit`,
      description: "Choose this building door as your destination.",
    })),
  ];

  els.exitButtons.innerHTML = options
    .map(
      (option, index) => `
        <button class="exit-choice-btn" type="button" data-exit-index="${index}">
          <span>
            <strong>${escapeHtml(option.label)}</strong>
            <small>${escapeHtml(option.description)}</small>
          </span>
          <span class="exit-arrow">→</span>
        </button>`
    )
    .join("");

  els.exitButtons.querySelectorAll(".exit-choice-btn").forEach((button) => {
    button.addEventListener("click", () => {
      const option = options[Number(button.dataset.exitIndex)];
      state.selectedDestination = {
        kind: "exit",
        exitMode: option.mode,
        floor_id: "G",
        code: option.code,
        name: option.label,
        type: "exit",
      };
      els.destinationSearch.value = option.label;
      els.exitButtons.querySelectorAll(".exit-choice-btn").forEach((b) => b.classList.remove("selected"));
      button.classList.add("selected");
      showToast(`${option.label} selected`);
    });
  });
}

async function useGps() {
  clearFormError();
  if (!navigator.geolocation) {
    showFormError("This browser does not provide geolocation. Choose a start location manually.");
    return;
  }

  els.gpsBtn.disabled = true;
  els.gpsBtn.querySelector("span:last-child").textContent = "Finding nearest entrance…";

  navigator.geolocation.getCurrentPosition(
    async (position) => {
      try {
        const { latitude, longitude, accuracy } = position.coords;
        const result = await api(
          `/nearest-entrance?latitude=${encodeURIComponent(latitude)}&longitude=${encodeURIComponent(longitude)}&accuracy_m=${encodeURIComponent(accuracy || 0)}`
        );
        const entrance = result.nearest_entrance;
        state.selectedStart = {
          kind: "location",
          floor_id: "G",
          code: entrance.node_id,
          name: entrance.label,
          type: "entrance",
        };
        els.startSearch.value = `${entrance.label} · GPS detected`;
        els.startSelection.hidden = false;
        els.startSelection.textContent = `${result.message} Distance: about ${Number(entrance.distance_m || 0).toFixed(1)} m.`;
        showToast(`Nearest entrance: ${entrance.label}`);
      } catch (error) {
        showFormError(error.message);
      } finally {
        els.gpsBtn.disabled = false;
        els.gpsBtn.querySelector("span:last-child").textContent = "Use outdoor GPS";
      }
    },
    (error) => {
      els.gpsBtn.disabled = false;
      els.gpsBtn.querySelector("span:last-child").textContent = "Use outdoor GPS";
      showFormError(
        error.code === 1
          ? "Location permission was denied. Choose your entrance/start point manually."
          : "GPS position could not be read. Try again outside near the building."
      );
    },
    { enableHighAccuracy: true, timeout: 12000, maximumAge: 5000 }
  );
}

function collectBlocked(extra = []) {
  const result = new Set(state.blocked);
  document.querySelectorAll(".avoid-buttons input:checked").forEach((input) => result.add(input.value));
  extra.forEach((item) => item && result.add(item));
  result.delete("STRING");
  return [...result];
}

function appendBlocked(params, blocked) {
  blocked.forEach((item) => params.append("blocked", item));
}

async function planRoute(overrides = {}) {
  clearFormError();

  const start = overrides.start || state.selectedStart;
  const destination = overrides.destination || state.selectedDestination;
  const mode = overrides.mode || selectedMode();
  const blocked = collectBlocked(overrides.blocked || []);

  if (!start) {
    showFormError("Choose your current room/start point, or use outdoor GPS.");
    return;
  }
  if (!destination) {
    showFormError('Choose a destination. You can also type "exit" to choose an exit.');
    return;
  }

  els.navigateBtn.disabled = true;
  els.navigateBtn.querySelector("span:first-child").textContent = "Calculating safe route…";

  try {
    const params = new URLSearchParams({
      start_floor: start.floor_id,
      start: start.code,
      mode,
    });
    appendBlocked(params, blocked);

    let route;
    if (destination.kind === "exit" && destination.exitMode === "nearest") {
      route = await api(`/route-to-exit?${params.toString()}`);
    } else {
      params.set("destination_floor", destination.floor_id);
      params.set("destination", destination.code);
      route = await api(`/route?${params.toString()}`);
    }

    state.route = route;
    state.blocked = new Set((route.blocked || []).filter((x) => x && x !== "STRING"));
    state.currentCheckpointIndex = 0;
    state.selectedFloor = route.floors[0];
    state.lastPlan = {
      destination: { ...destination },
      mode,
    };

    buildGlobalPathIndexes();
    renderRouteSummary();
    renderInstructions();
    renderFloorButtons();
    updateProgressUi();
    els.routeSummary.hidden = false;
    els.floatingNavControls.hidden = false;
    els.stepBar.hidden = false;
    els.currentStepCard.hidden = false;
    els.routeInstructionsCard.hidden = false;

    await loadFloorMap(state.selectedFloor, true);
    centerCurrentCheckpoint();
    showToast("Route ready — tap route dots as you reach them");
  } catch (error) {
    console.error(error);
    showFormError(error.message);
  } finally {
    els.navigateBtn.disabled = false;
    els.navigateBtn.querySelector("span:first-child").textContent = "Start navigation";
  }
}

function renderRouteSummary() {
  const r = state.route;
  if (!r) return;
  const destinationLabel = r.destination === "EXIT" && r.chosen_exit ? r.chosen_exit.label : r.destination;
  els.summaryRouteText.textContent = `${r.start} → ${destinationLabel}`;
  els.summaryMode.textContent = humanize(r.mode);
  els.summaryCost.textContent = `${r.total_cost} m`;
  els.summaryFloors.textContent = r.floors.join(" → ");
}

function buildGeometryDirections() {
  const output = [];
  const route = state.route;
  if (!route) return output;

  for (const floor of route.floors || []) {
    const points = route.floor_routes?.[floor] || [];
    if (points.length < 3) continue;

    for (let i = 1; i < points.length - 1; i++) {
      const a = points[i - 1], b = points[i], c = points[i + 1];
      const v1x = b.x - a.x, v1y = b.y - a.y;
      const v2x = c.x - b.x, v2y = c.y - b.y;
      const l1 = Math.hypot(v1x, v1y), l2 = Math.hypot(v2x, v2y);
      if (l1 < 0.001 || l2 < 0.001) continue;

      const dot = (v1x * v2x + v1y * v2y) / (l1 * l2);
      const angle = Math.acos(Math.max(-1, Math.min(1, dot))) * 180 / Math.PI;
      if (angle < 38) continue;

      // SVG coordinates have +Y downward. Positive cross therefore represents
      // a clockwise/right turn on the displayed floor. A 90° rotation preserves
      // handedness, so the same left/right remains valid after display rotation.
      const cross = v1x * v2y - v1y * v2x;
      const direction = cross > 0 ? "right" : "left";
      const pathIndex = state.floorRouteIndexes?.[floor]?.[i]?.globalIndex;
      const nearby = (route.checkpoints || []).find(
        (cp) => cp.floor_id === floor && Math.abs((cp.path_index ?? -999) - pathIndex) <= 2
      );
      const context = nearby && !/^Route checkpoint$/i.test(nearby.label || "")
        ? ` near ${String(nearby.label).replace(/^Near\s+/i, "")}`
        : "";
      output.push({
        type: "turn",
        floor,
        text: `Turn ${direction}${context} and continue along the corridor`,
        pathIndex: Number.isFinite(pathIndex) ? pathIndex : i,
      });
    }
  }
  return output;
}

function renderInstructions() {
  const route = state.route;
  if (!route) return;

  const backend = (route.instructions || [])
    .filter((item) => item.type !== "start")
    .map((item) => ({ ...item, source: "backend" }));
  const turns = buildGeometryDirections().map((item) => ({ ...item, source: "geometry" }));

  const items = [];
  items.push({ type: "start", floor: route.floors?.[0] || "", text: `Start at ${route.start}` });

  // Keep backend connector/floor-change instructions authoritative. Add only
  // significant geometric turns; no route geometry is altered by this wording.
  for (const floor of route.floors || []) {
    turns
      .filter((item) => item.floor === floor)
      .sort((a, b) => a.pathIndex - b.pathIndex)
      .forEach((item) => items.push(item));

    backend
      .filter((item) => (item.floor || item.from_floor || item.to_floor) === floor)
      .forEach((item) => items.push(item));
  }

  // Some final backend instructions may not match the simple floor filter.
  backend.forEach((item) => {
    if (!items.some((x) => x.text === item.text)) items.push(item);
  });

  const cleaned = items.filter(
    (item, index, arr) => index === 0 || item.text !== arr[index - 1].text
  );

  els.instructionCount.textContent = `${cleaned.length} step${cleaned.length === 1 ? "" : "s"}`;
  els.routeInstructions.innerHTML = cleaned
    .map((item, index) => `
      <div class="instruction-item">
        <span class="instruction-number">${index + 1}</span>
        <span class="instruction-copy">
          <strong>${escapeHtml(item.text)}</strong>
          <span>${escapeHtml(item.floor || item.to_floor || "")}</span>
        </span>
      </div>`)
    .join("");
}

function buildGlobalPathIndexes() {
  state.floorRouteIndexes = {};
  if (!state.route) return;
  const raw = state.route.raw_node_path || [];
  let cursor = 0;

  for (const floor of state.route.floors || []) {
    const points = state.route.floor_routes?.[floor] || [];
    state.floorRouteIndexes[floor] = [];
    for (const point of points) {
      let found = -1;
      for (let i = cursor; i < raw.length; i++) {
        if (raw[i] === point.node_id) {
          found = i;
          cursor = i + 1;
          break;
        }
      }
      state.floorRouteIndexes[floor].push({ ...point, globalIndex: found });
    }
  }
}

function renderFloorButtons() {
  const floors = state.route?.floors?.length ? state.route.floors : state.floors.map((f) => f.floor_id);
  els.floorButtons.innerHTML = floors
    .map(
      (floor) => `
        <button class="floor-button ${floor === state.selectedFloor ? "active" : ""}" type="button" data-floor="${escapeHtml(floor)}">
          <strong>${escapeHtml(floor)}</strong>
          <span>${escapeHtml(shortFloorName(floorName(floor)))}</span>
        </button>`
    )
    .join("");

  els.floorButtons.querySelectorAll(".floor-button").forEach((button) => {
    button.addEventListener("click", async () => {
      state.selectedFloor = button.dataset.floor;
      renderFloorButtons();
      await loadFloorMap(state.selectedFloor, true);
    });
  });
}

function shortFloorName(name) {
  return String(name).replace(/ floor/i, "");
}

function updateProgressUi() {
  if (!state.route?.checkpoints?.length) return;
  const cp = state.route.checkpoints[state.currentCheckpointIndex];
  const next = state.route.checkpoints[state.currentCheckpointIndex + 1];
  const progress = Number(cp.progress_percent || 0);

  els.progressPercent.textContent = `${progress}%`;
  els.progressFill.style.width = `${Math.max(0, Math.min(100, progress))}%`;
  els.currentLandmark.textContent = cp.label;
  els.remainingText.textContent = `${cp.remaining_distance_m} m remaining`;
  els.previousCheckpointBtn.disabled = state.currentCheckpointIndex <= 0;

  els.currentStepTitle.textContent = cp.label;
  els.currentStepFloor.textContent = `${floorName(cp.floor_id)} · manually confirmed checkpoint`;

  if (next) {
    els.nextStepTitle.textContent = next.label;
    els.nextStepSubtitle.textContent = `${floorName(next.floor_id)} · tap dot ${next.checkpoint} only after you physically reach it`;
  } else {
    els.nextStepTitle.textContent = "Destination reached";
    els.nextStepSubtitle.textContent = "Navigation complete";
  }
}

async function reachCheckpoint(index) {
  if (!state.route?.checkpoints?.[index] || index < state.currentCheckpointIndex) return;
  if (index > state.currentCheckpointIndex + 1) {
    showToast("Confirm checkpoints in order — tap the next dot first");
    return;
  }

  state.currentCheckpointIndex = index;
  const cp = state.route.checkpoints[index];
  const next = state.route.checkpoints[index + 1];

  updateProgressUi();

  // Cross-floor hand-off:
  // Once the user confirms the connector checkpoint (lift/stairs) on the
  // current floor, immediately display the next routed floor. Previously the
  // app stayed on the old floor, while the next tappable checkpoint existed
  // only on the new floor, which trapped navigation at the connector.
  const hasFloorTransition = Boolean(next && next.floor_id && next.floor_id !== cp.floor_id);
  const displayFloor = hasFloorTransition ? next.floor_id : cp.floor_id;

  state.selectedFloor = displayFloor;
  renderFloorButtons();
  await loadFloorMap(displayFloor, false);

  if (hasFloorTransition) {
    // Center on the next floor's arrival checkpoint so the user sees where
    // to continue after exiting the lift/stairs. Progress still remains at
    // the last manually confirmed checkpoint until that next dot is tapped.
    centerOnCheckpoint(next);
    showToast(`Take the ${connectorWord(cp, next)} to ${floorName(next.floor_id)} · the map has switched automatically`);
  } else {
    centerOnCheckpoint(cp);
    showToast(
      index === state.route.checkpoints.length - 1
        ? "Destination reached"
        : `Progress updated · ${cp.progress_percent}%`
    );
  }
}

function connectorWord(cp, next) {
  const text = `${cp?.label || ""} ${next?.label || ""}`.toLowerCase();
  if (text.includes("stair")) return "stairs";
  if (text.includes("lift") || text.includes("elevator")) return "lift";
  return "connector";
}

async function previousCheckpoint() {
  if (!state.route || state.currentCheckpointIndex <= 0) return;
  state.currentCheckpointIndex -= 1;
  const cp = state.route.checkpoints[state.currentCheckpointIndex];
  state.selectedFloor = cp.floor_id;
  renderFloorButtons();
  updateProgressUi();
  await loadFloorMap(cp.floor_id, false);
  centerOnCheckpoint(cp);
  showToast("Moved back to the previous checkpoint");
}

function centerCurrentCheckpoint() {
  const cp = state.route?.checkpoints?.[state.currentCheckpointIndex];
  if (cp && cp.floor_id === state.selectedFloor) centerOnCheckpoint(cp);
  else if (cp) {
    state.selectedFloor = cp.floor_id;
    renderFloorButtons();
    loadFloorMap(cp.floor_id, false).then(() => centerOnCheckpoint(cp));
  }
}

function clearRoute() {
  state.route = null;
  state.lastPlan = null;
  state.currentCheckpointIndex = 0;
  state.blocked.clear();
  state.floorRouteIndexes = {};
  els.routeSummary.hidden = true;
  els.floatingNavControls.hidden = true;
  els.stepBar.hidden = true;
  els.currentStepCard.hidden = true;
  els.routeInstructionsCard.hidden = true;
  if (state.currentSvg) state.currentSvg.querySelector("#campusnav-route-overlay")?.remove();
  document.querySelectorAll(".avoid-buttons input").forEach((input) => (input.checked = false));
  renderFloorButtons();
  showToast("Route cleared");
}

async function loadFloorMap(floorId, fitAfter = true) {
  state.selectedFloor = floorId;
  state.sourceViewBox = null;
  state.rotationGroup = null;
  renderFloorButtons();
  els.currentFloorTitle.textContent = `${floorId} · ${floorName(floorId)}`;
  els.mapLoading.innerHTML = `<div class="spinner"></div><span>Loading ${escapeHtml(floorName(floorId))}…</span>`;
  els.mapLoading.style.display = "grid";
  els.svgHost.innerHTML = "";

  try {
    const map = state.maps.get(floorId);
    if (!map?.url) throw new Error(`No SVG map is registered for ${floorId}.`);
    const svgText = await api(map.url);
    const doc = new DOMParser().parseFromString(svgText, "image/svg+xml");
    if (doc.querySelector("parsererror")) throw new Error(`${floorId} SVG could not be parsed.`);

    const svg = document.importNode(doc.documentElement, true);
    svg.removeAttribute("width");
    svg.removeAttribute("height");
    svg.setAttribute("preserveAspectRatio", "xMidYMid meet");
    svg.setAttribute("aria-label", `${floorName(floorId)} map`);
    els.svgHost.replaceChildren(svg);
    state.currentSvg = svg;

    // Decorate in the SVG's native coordinate system first. Then rotate the
    // complete rendered map in one shared group. Route coordinates remain in
    // their original backend/SVG coordinate system and therefore stay aligned.
    decorateBlueprint(svg, floorId);
    const rotatedViewBox = enableClockwiseMapRotation(svg);
    state.originalViewBox = { ...rotatedViewBox };
    state.viewBox = { ...rotatedViewBox };
    applyViewBox();

    drawRouteOverlay();
    if (fitAfter) fitMap();
    els.mapLoading.style.display = "none";
  } catch (error) {
    console.error(error);
    els.mapLoading.innerHTML = `<span>${escapeHtml(error.message)}</span>`;
    els.mapLoading.style.display = "grid";
  }
}

function enableClockwiseMapRotation(svg) {
  // Frontend-only rotation. We do NOT touch the real SVG file or database.
  //
  // Source viewBox: (x0, y0, width, height)
  // 90° clockwise display mapping:
  //   x' = height + y0 - y
  //   y' = x - x0
  // The resulting display viewBox is 0 0 height width.
  const source = getViewBox(svg);
  state.sourceViewBox = { ...source };

  const group = document.createElementNS(SVG_NS, "g");
  group.id = "campusnav-clockwise-map";
  group.setAttribute(
    "transform",
    `matrix(0 1 -1 0 ${source.h + source.y} ${-source.x})`
  );

  // Keep non-rendered document resources at root level. Move every rendered
  // map element into the same group so blueprint, route, dots and arrows all
  // share exactly one transform.
  const rootOnly = new Set(["defs", "metadata", "title", "desc", "namedview"]);
  [...svg.childNodes].forEach((node) => {
    if (node.nodeType === 1 && rootOnly.has(String(node.localName || "").toLowerCase())) return;
    group.appendChild(node);
  });

  svg.appendChild(group);
  svg.setAttribute("viewBox", `0 0 ${source.h} ${source.w}`);
  state.rotationGroup = group;

  return { x: 0, y: 0, w: source.h, h: source.w };
}

function sourcePointToDisplay(x, y) {
  const source = state.sourceViewBox;
  if (!source) return { x, y };
  return {
    x: source.h + source.y - y,
    y: x - source.x,
  };
}


function drawFloorSpecificSemanticOverlays(svg, floorId) {
  svg.querySelector("#campusnav-semantic-overlays")?.remove();
  const entries = window.CAMPUSNAV_SCHEMATIC_OVERLAYS?.[floorId] || [];
  if (!entries.length) return;

  const locationMap = new Map(
    (state.locationsByFloor.get(floorId) || []).map(item => [
      String(item.code || "").trim().toUpperCase(), item
    ])
  );

  const layer = document.createElementNS(SVG_NS, "g");
  layer.id = "campusnav-semantic-overlays";
  layer.setAttribute("pointer-events", "none");

  for (const entry of entries) {
    const location = locationMap.get(String(entry.code).toUpperCase()) || {
      code: entry.code, name: entry.code, type: "classroom"
    };
    const kind = semanticRoomClass(location);
    const polygon = document.createElementNS(SVG_NS, "polygon");
    polygon.setAttribute("points", entry.points.map(p => p.join(",")).join(" "));
    polygon.setAttribute("class", `cn-safe-room-fill cn-space-${kind}`);
    polygon.dataset.roomCode = entry.code;
    layer.appendChild(polygon);
  }

  // Keep fills underneath architectural walls/labels and underneath the active route.
  const firstMapLayer = [...svg.children].find(el => el.tagName?.toLowerCase() === "g");
  if (firstMapLayer) svg.insertBefore(layer, firstMapLayer);
  else svg.appendChild(layer);
}

function decorateBlueprint(svg, floorId) {
  // Build the permanent, road-style corridor area BEFORE hiding NAV layers.
  // Only corridor/infrastructure/entrance access edges are used; room-door
  // connector spurs are excluded so the pale corridor does not flood rooms.
  buildWholeFloorCorridorNetwork(svg, floorId);

  hideTechnicalGraph(svg);
  drawFloorSpecificSemanticOverlays(svg, floorId);
  colorInfrastructure(svg);
  colorRoomLabels(svg, floorId);
}


function layerToken(group) {
  const id = normalizeText(group?.id || "");
  const label = normalizeText(
    group?.getAttributeNS?.(INKSCAPE_NS, "label") ||
    group?.getAttribute?.("inkscape:label") ||
    ""
  );
  return `${id} ${label}`;
}

function findLayer(svg, pattern) {
  return [...svg.querySelectorAll("g")].find((group) => pattern.test(layerToken(group))) || null;
}

function classifyNavNodeForCorridor(nodeId, floorId) {
  const id = String(nodeId || "").trim();
  const upper = id.toUpperCase();

  const floorLocations = state.locationsByFloor.get(floorId) || [];
  const location = floorLocations.find(
    (item) => String(item.code || "").trim().toUpperCase() === upper
  );

  if (location) {
    const type = normalizeText(location.type);
    // Physical destinations are not part of the permanent corridor surface.
    if (/room|classroom|lab|faculty|office|toilet|bathroom|washroom|wc/.test(type)) {
      return "destination";
    }
  }

  if (/^LIFT\d*/i.test(id)) return "lift";
  if (/^STAIR/i.test(id)) return "stairs";
  if (/^ENTRANCE/i.test(id)) return "entrance";

  // Some room/location nodes do not carry a good type; use the location code
  // itself as a second safety check.
  if (location) return "destination";

  return "corridor";
}

function collectNavNodes(nodeLayer, floorId) {
  if (!nodeLayer) return [];
  const nodes = [];

  nodeLayer.querySelectorAll("circle, ellipse").forEach((shape) => {
    const x = Number(shape.getAttribute("cx"));
    const y = Number(shape.getAttribute("cy"));
    if (!Number.isFinite(x) || !Number.isFinite(y)) return;

    nodes.push({
      id: shape.id || "",
      x,
      y,
      kind: classifyNavNodeForCorridor(shape.id || "", floorId),
    });
  });

  return nodes;
}

function nearestNavNode(point, nodes) {
  let best = null;
  let bestDistance = Infinity;

  for (const node of nodes) {
    const distance = Math.hypot(node.x - point.x, node.y - point.y);
    if (distance < bestDistance) {
      bestDistance = distance;
      best = node;
    }
  }

  return bestDistance <= CORRIDOR_NODE_MATCH_TOLERANCE ? best : null;
}

function navEdgeEndpoints(shape) {
  const tag = String(shape.localName || "").toLowerCase();

  if (tag === "line") {
    const x1 = Number(shape.getAttribute("x1"));
    const y1 = Number(shape.getAttribute("y1"));
    const x2 = Number(shape.getAttribute("x2"));
    const y2 = Number(shape.getAttribute("y2"));
    if ([x1, y1, x2, y2].every(Number.isFinite)) {
      return [{ x: x1, y: y1 }, { x: x2, y: y2 }];
    }
  }

  if (tag === "polyline") {
    const raw = String(shape.getAttribute("points") || "").trim();
    const values = raw.split(/[\s,]+/).map(Number).filter(Number.isFinite);
    if (values.length >= 4) {
      return [
        { x: values[0], y: values[1] },
        { x: values[values.length - 2], y: values[values.length - 1] },
      ];
    }
  }

  if (tag === "path") {
    // Browser-native geometry is safest for future SVGs with more than M/L.
    try {
      const total = shape.getTotalLength();
      if (Number.isFinite(total) && total > 0) {
        const a = shape.getPointAtLength(0);
        const b = shape.getPointAtLength(total);
        return [{ x: a.x, y: a.y }, { x: b.x, y: b.y }];
      }
    } catch (_) {}

    // Fallback for current floor files: M x,y L x,y
    const d = String(shape.getAttribute("d") || "");
    const nums = (d.match(/-?\d+(?:\.\d+)?/g) || []).map(Number);
    if (nums.length >= 4) {
      return [
        { x: nums[0], y: nums[1] },
        { x: nums[nums.length - 2], y: nums[nums.length - 1] },
      ];
    }
  }

  return null;
}


function corridorSegmentLength(shape) {
  const endpoints = navEdgeEndpoints(shape);
  if (!endpoints) return 0;
  return Math.hypot(
    endpoints[1].x - endpoints[0].x,
    endpoints[1].y - endpoints[0].y
  );
}

function cloneCorridorGeometry(shape, className) {
  const clone = shape.cloneNode(false);
  clone.removeAttribute("id");
  clone.removeAttribute("style");
  clone.removeAttribute("stroke");
  clone.removeAttribute("stroke-width");
  clone.removeAttribute("fill");
  clone.removeAttribute("class");
  clone.setAttribute("class", className);
  clone.setAttribute("pointer-events", "none");
  return clone;
}

function buildWholeFloorCorridorNetwork(svg, floorId) {
  svg.querySelector("#campusnav-floor-corridors")?.remove();

  const nodeLayer = findLayer(
    svg,
    /nav[\s_-]*nodes|navigation[\s_-]*nodes/
  );
  const edgeLayer = findLayer(
    svg,
    /nav[\s_-]*edges|navigation[\s_-]*edges/
  );

  if (!nodeLayer || !edgeLayer) {
    console.warn("CampusNav: NAV node/edge layers not found; corridor surface skipped.");
    return;
  }

  const nodes = collectNavNodes(nodeLayer, floorId);
  if (!nodes.length) return;

  const edgeShapes = [...edgeLayer.querySelectorAll("path, line, polyline")];
  const accepted = [];
  const degree = new Map();

  const bumpDegree = (nodeId) => {
    degree.set(nodeId, (degree.get(nodeId) || 0) + 1);
  };

  for (const edge of edgeShapes) {
    const endpoints = navEdgeEndpoints(edge);
    if (!endpoints) continue;

    const a = nearestNavNode(endpoints[0], nodes);
    const b = nearestNavNode(endpoints[1], nodes);
    if (!a || !b) continue;

    // Never paint a broad corridor surface into a room/lab/office/toilet.
    if (a.kind === "destination" || b.kind === "destination") continue;

    const allowedKinds = new Set(["corridor", "entrance", "lift", "stairs"]);
    if (!allowedKinds.has(a.kind) || !allowedKinds.has(b.kind)) continue;

    // Keep actual hallway access. Skip odd tiny infrastructure-to-infrastructure
    // artefacts that are not part of the walkable corridor.
    const hasWalkableEndpoint =
      a.kind === "corridor" ||
      b.kind === "corridor" ||
      a.kind === "entrance" ||
      b.kind === "entrance";

    if (!hasWalkableEndpoint) continue;

    // Tiny graph fragments create visual bumps but add no useful corridor shape.
    const segmentLength = corridorSegmentLength(edge);
    if (segmentLength < 5) continue;

    accepted.push({ edge, a, b });
    bumpDegree(a.id);
    bumpDegree(b.id);
  }

  if (!accepted.length) {
    console.warn(`CampusNav: no safe corridor edges reconstructed for ${floorId}.`);
    return;
  }

  const group = document.createElementNS(SVG_NS, "g");
  group.id = "campusnav-floor-corridors";
  group.setAttribute("aria-label", "Walkable corridor area");
  group.setAttribute("pointer-events", "none");

  const borderGroup = document.createElementNS(SVG_NS, "g");
  borderGroup.setAttribute("class", "cn-floor-corridor-border-group");

  const roadGroup = document.createElementNS(SVG_NS, "g");
  roadGroup.setAttribute("class", "cn-floor-corridor-road-group");

  for (const { edge } of accepted) {
    borderGroup.appendChild(
      cloneCorridorGeometry(edge, "cn-floor-corridor-border")
    );
    roadGroup.appendChild(
      cloneCorridorGeometry(edge, "cn-floor-corridor-road")
    );
  }

  // Separate graph edges are used in the source SVG, so flat line caps are
  // cleaner at dead ends. Small junction discs are added ONLY where two or
  // more corridor edges really meet, preventing the giant circular blobs
  // visible in v6.
  const junctionBorderGroup = document.createElementNS(SVG_NS, "g");
  junctionBorderGroup.setAttribute("class", "cn-floor-corridor-junction-border-group");

  const junctionRoadGroup = document.createElementNS(SVG_NS, "g");
  junctionRoadGroup.setAttribute("class", "cn-floor-corridor-junction-road-group");

  for (const node of nodes) {
    const d = degree.get(node.id) || 0;
    if (d < 2) continue;
    if (node.kind !== "corridor" && node.kind !== "entrance") continue;

    const border = document.createElementNS(SVG_NS, "circle");
    border.setAttribute("cx", node.x);
    border.setAttribute("cy", node.y);
    border.setAttribute("r", CORRIDOR_VISUAL_BORDER_UNITS / 2);
    border.setAttribute("class", "cn-floor-corridor-junction-border");

    const road = document.createElementNS(SVG_NS, "circle");
    road.setAttribute("cx", node.x);
    road.setAttribute("cy", node.y);
    road.setAttribute("r", CORRIDOR_VISUAL_WIDTH_UNITS / 2);
    road.setAttribute("class", "cn-floor-corridor-junction-road");

    junctionBorderGroup.appendChild(border);
    junctionRoadGroup.appendChild(road);
  }

  group.append(
    borderGroup,
    junctionBorderGroup,
    roadGroup,
    junctionRoadGroup
  );

  // Place corridor BELOW architectural walls/labels so walls visually clip
  // the corridor. This keeps the floor plan readable and clean.
  const firstRenderable = [...svg.children].find(
    (el) =>
      !["defs", "metadata", "title", "desc", "namedview"].includes(
        String(el.localName || "").toLowerCase()
      )
  );

  if (firstRenderable) svg.insertBefore(group, firstRenderable);
  else svg.appendChild(group);

  console.info(
    `CampusNav: clean corridor surface built from ${accepted.length} safe segments on ${floorId}.`
  );
}

function hideTechnicalGraph(svg) {
  svg.querySelectorAll("g").forEach((group) => {
    const id = normalizeText(group.id);
    const label = normalizeText(group.getAttributeNS(INKSCAPE_NS, "label") || group.getAttribute("inkscape:label"));
    const token = `${id} ${label}`;
    if (/nav[\s_-]*nodes|nav[\s_-]*edges|navigation[\s_-]*nodes|navigation[\s_-]*edges/.test(token)) {
      group.classList.add("cn-hide-graph");
    }
  });

  // Fallback for older maps whose graph was not grouped cleanly.
  svg.querySelectorAll("circle, ellipse").forEach((shape) => {
    if (shape.closest("#campusnav-route-overlay") || shape.closest(".cn-hide-graph")) return;
    const style = normalizeText(shape.getAttribute("style"));
    const fill = normalizeText(shape.getAttribute("fill"));
    if (/008000|0093ff|1597e5/.test(style + fill)) shape.style.display = "none";
  });
}

function colorInfrastructure(svg) {
  const infrastructureGroups = [...svg.querySelectorAll("g")].filter((group) => {
    const id = normalizeText(group.id);
    const label = normalizeText(group.getAttributeNS(INKSCAPE_NS, "label") || group.getAttribute("inkscape:label"));
    return /infrastructure/.test(`${id} ${label}`);
  });

  infrastructureGroups.forEach((group) => {
    const labels = [...group.querySelectorAll("text")].filter((text) => /lift|stair|steps/i.test(text.textContent || ""));
    const shapes = [...group.querySelectorAll("rect, path, polygon, polyline")];
    const usedShapes = new Set();

    labels.forEach((label) => {
      const isLift = /lift/i.test(label.textContent || "");
      label.classList.add(isLift ? "cn-infra-lift-label" : "cn-infra-stair-label");

      const nearest = nearestSvgShape(label, shapes.filter((shape) => !usedShapes.has(shape)));
      if (nearest) {
        usedShapes.add(nearest);
        nearest.classList.add(isLift ? "cn-infra-lift-shape" : "cn-infra-stair-shape");
      }
    });
  });
}

function nearestSvgShape(source, shapes) {
  let sourceBox;
  try { sourceBox = source.getBBox(); } catch (_) { return null; }
  const sx = sourceBox.x + sourceBox.width / 2;
  const sy = sourceBox.y + sourceBox.height / 2;
  let best = null;
  let bestDistance = Infinity;

  for (const shape of shapes) {
    try {
      const box = shape.getBBox();
      if (!box.width && !box.height) continue;
      const cx = box.x + box.width / 2;
      const cy = box.y + box.height / 2;
      const distance = Math.hypot(cx - sx, cy - sy);
      if (distance < bestDistance) {
        bestDistance = distance;
        best = shape;
      }
    } catch (_) {}
  }
  return best;
}

function semanticRoomClass(location) {
  const hay = normalizeText(`${location?.type || ""} ${location?.name || ""} ${location?.code || ""}`);
  if (/toilet|bathroom|washroom|restroom|\bwc\b/.test(hay)) return "bathroom";
  if (/research|laboratory|\blab\b/.test(hay)) return "lab";
  if (/faculty|office|admin|staff/.test(hay)) return "office";
  if (/electrical|utility|store|storage|server|service|mechanical/.test(hay)) return "utility";
  if (/courtyard|open area|garden|atrium/.test(hay)) return "courtyard";
  return "classroom";
}

function semanticTypeLabel(kind, location) {
  if (kind === "bathroom") return "Bathroom";
  if (kind === "lab") return "Research Lab";
  if (kind === "office") return /faculty/i.test(`${location?.type||""} ${location?.name||""}`) ? "Faculty / Office" : "Office";
  if (kind === "utility") return "Utility";
  if (kind === "courtyard") return "Open Area";
  return "Classroom";
}

function colorRoomLabels(svg, floorId) {
  const locationMap = new Map(
    (state.locationsByFloor.get(floorId) || []).map((item) => [
      String(item.code || "").trim().toUpperCase(), item
    ])
  );

  const roomGroups = [...svg.querySelectorAll("g")].filter((group) => {
    const token = normalizeText(`${group.id} ${group.getAttributeNS(INKSCAPE_NS,"label") || group.getAttribute("inkscape:label") || ""}`);
    return /rooms?|spaces?|class|facilit/.test(token);
  });
  const groups = roomGroups.length ? roomGroups : [svg];

  groups.forEach((group) => {
    const shapes = [...group.querySelectorAll("rect, path, polygon")].filter((shape) => {
      if (shape.closest("#campusnav-floor-corridors") || shape.closest("#campusnav-route-overlay")) return false;
      try { const b=shape.getBBox(); return b.width>10 && b.height>10; } catch (_) { return false; }
    });
    const usedShapes = new Set();

    [...group.querySelectorAll("text")].forEach((label) => {
      const raw=String(label.textContent||"").trim();
      const location=locationMap.get(raw.toUpperCase());
      if (!location) return;

      const kind=semanticRoomClass(location);
      const nearest=nearestSvgShape(label, shapes.filter(s=>!usedShapes.has(s)));
      if (nearest) {
        usedShapes.add(nearest);
        nearest.classList.add("cn-semantic-space", `cn-space-${kind}`);
      }

      // Replace blueprint-like label treatment with a clean two-line semantic label.
      label.classList.add("cn-space-label");
      let box; try { box=label.getBBox(); } catch (_) { box=null; }
      const x = label.getAttribute("x") || (box ? box.x + box.width/2 : "0");
      while (label.firstChild) label.removeChild(label.firstChild);
      label.setAttribute("text-anchor","middle");
      label.setAttribute("x",x);

      const title=document.createElementNS(SVG_NS,"tspan");
      title.setAttribute("x",x); title.setAttribute("dy","0");
      title.setAttribute("class","cn-space-label-title");
      title.textContent = kind === "bathroom" ? "🚻" : (location.name && !/room/i.test(location.name) ? location.name : location.code);

      const subtitle=document.createElementNS(SVG_NS,"tspan");
      subtitle.setAttribute("x",x); subtitle.setAttribute("dy","1.25em");
      subtitle.setAttribute("class","cn-space-label-type");
      subtitle.textContent = semanticTypeLabel(kind, location);
      label.append(title,subtitle);
    });
  });
}

function drawRouteOverlay() {
  const svg = state.currentSvg;
  if (!svg) return;
  svg.querySelector("#campusnav-route-overlay")?.remove();
  if (!state.route) return;

  const floor = state.selectedFloor;
  const allPoints = state.floorRouteIndexes[floor] || [];
  if (!allPoints.length) return;

  const currentCheckpoint = state.route.checkpoints?.[state.currentCheckpointIndex];
  const currentPathIndex = currentCheckpoint?.path_index ?? 0;
  const remaining = allPoints.filter((point) => point.globalIndex === -1 || point.globalIndex >= currentPathIndex);
  if (!remaining.length) return;

  const floorCheckpoints = (state.route.checkpoints || []).filter(
    (cp) => cp.floor_id === floor && cp.path_index >= currentPathIndex
  );
  const protectedIndexes = new Set(floorCheckpoints.map((cp) => cp.path_index));
  const cleaned = simplifyMicroJitter(remaining, protectedIndexes);

  const group = document.createElementNS(SVG_NS, "g");
  group.id = "campusnav-route-overlay";

  const defs = document.createElementNS(SVG_NS, "defs");
  const marker = document.createElementNS(SVG_NS, "marker");
  marker.id = "cn-route-arrow";
  marker.setAttribute("markerWidth", "7");
  marker.setAttribute("markerHeight", "7");
  marker.setAttribute("refX", "6");
  marker.setAttribute("refY", "3.5");
  marker.setAttribute("orient", "auto");
  marker.setAttribute("markerUnits", "strokeWidth");
  const arrowPath = document.createElementNS(SVG_NS, "path");
  arrowPath.setAttribute("d", "M0,0 L7,3.5 L0,7 Z");
  arrowPath.setAttribute("fill", "#ff5b64");
  marker.appendChild(arrowPath);
  defs.appendChild(marker);
  group.appendChild(defs);

  if (cleaned.length >= 2) {
    const pointsText = cleaned.map((p) => `${p.x},${p.y}`).join(" ");
    const corridor = document.createElementNS(SVG_NS, "polyline");
    corridor.setAttribute("points", pointsText);
    corridor.setAttribute("class", "cn-route-corridor");
    corridor.setAttribute("pointer-events", "none");

    const halo = document.createElementNS(SVG_NS, "polyline");
    halo.setAttribute("points", pointsText);
    halo.setAttribute("class", "cn-route-halo");
    halo.setAttribute("pointer-events", "none");

    const line = document.createElementNS(SVG_NS, "polyline");
    line.setAttribute("points", pointsText);
    line.setAttribute("class", "cn-route-line");
    line.setAttribute("marker-end", "url(#cn-route-arrow)");
    line.setAttribute("pointer-events", "none");

    group.append(corridor, halo, line);
    drawDirectionArrows(group, cleaned);
  }

  floorCheckpoints.forEach((cp) => {
    const index = state.route.checkpoints.indexOf(cp);
    drawCheckpoint(group, cp, index);
  });

  (state.rotationGroup || svg).appendChild(group);
  updateOverlayScale();
}

function simplifyMicroJitter(points, protectedPathIndexes) {
  if (points.length < 3 || !state.currentSvg) return points;
  const unitsPerPx = getUnitsPerPixel();
  const maxDeviation = 1.5 * unitsPerPx;
  const output = [points[0]];

  for (let i = 1; i < points.length - 1; i++) {
    const a = output[output.length - 1];
    const b = points[i];
    const c = points[i + 1];
    if (protectedPathIndexes.has(b.globalIndex)) {
      output.push(b);
      continue;
    }

    const abx = b.x - a.x;
    const aby = b.y - a.y;
    const bcx = c.x - b.x;
    const bcy = c.y - b.y;
    const abLen = Math.hypot(abx, aby);
    const bcLen = Math.hypot(bcx, bcy);
    if (!abLen || !bcLen) continue;

    const dot = (abx * bcx + aby * bcy) / (abLen * bcLen);
    const angle = Math.acos(Math.max(-1, Math.min(1, dot))) * 180 / Math.PI;
    const deviation = pointToSegmentDistance(b, a, c);

    // Only remove almost-collinear micro-jitter. Real turns are untouched.
    if (angle < 6 && deviation <= maxDeviation) continue;
    output.push(b);
  }
  output.push(points[points.length - 1]);
  return output;
}

function pointToSegmentDistance(p, a, b) {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  if (dx === 0 && dy === 0) return Math.hypot(p.x - a.x, p.y - a.y);
  const t = Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / (dx * dx + dy * dy)));
  const x = a.x + t * dx;
  const y = a.y + t * dy;
  return Math.hypot(p.x - x, p.y - y);
}

function drawDirectionArrows(group, points) {
  if (points.length < 2) return;

  // Draw explicit SVG triangles rather than relying only on marker-end.
  // This stays visible in imported Inkscape SVGs and after the shared
  // 90° clockwise transform.
  const unitsPerPx = getUnitsPerPixel();
  const desiredSpacing = 105 * unitsPerPx;
  const arrowLength = Math.max(8 * unitsPerPx, 7);
  const arrowWidth = Math.max(5.5 * unitsPerPx, 5);
  let distanceSinceArrow = desiredSpacing * 0.45;

  for (let i = 0; i < points.length - 1; i++) {
    const a = points[i];
    const b = points[i + 1];
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    const segment = Math.hypot(dx, dy);
    if (segment <= 0.001) continue;

    const ux = dx / segment;
    const uy = dy / segment;
    let position = Math.max(0, desiredSpacing - distanceSinceArrow);

    while (position < segment - arrowLength * 1.3) {
      const cx = a.x + ux * position;
      const cy = a.y + uy * position;
      const tipX = cx + ux * arrowLength * 0.7;
      const tipY = cy + uy * arrowLength * 0.7;
      const baseX = cx - ux * arrowLength * 0.55;
      const baseY = cy - uy * arrowLength * 0.55;
      const px = -uy * arrowWidth * 0.5;
      const py = ux * arrowWidth * 0.5;

      const arrow = document.createElementNS(SVG_NS, "polygon");
      arrow.setAttribute(
        "points",
        `${tipX},${tipY} ${baseX + px},${baseY + py} ${baseX - px},${baseY - py}`
      );
      arrow.setAttribute("class", "cn-route-arrowhead");
      group.appendChild(arrow);

      position += desiredSpacing;
    }

    distanceSinceArrow = segment - Math.max(0, position - desiredSpacing);
    if (distanceSinceArrow > desiredSpacing) distanceSinceArrow %= desiredSpacing;
  }
}

function drawCheckpoint(group, cp, index) {
  const isCurrent = index === state.currentCheckpointIndex;
  const isDestination = index === state.route.checkpoints.length - 1;

  const hit = document.createElementNS(SVG_NS, "circle");
  hit.setAttribute("cx", cp.x);
  hit.setAttribute("cy", cp.y);
  hit.setAttribute("class", "cn-checkpoint-hit");
  hit.dataset.radiusPx = "17";
  hit.dataset.checkpointIndex = String(index);
  hit.addEventListener("click", () => reachCheckpoint(index));
  group.appendChild(hit);

  const circle = document.createElementNS(SVG_NS, "circle");
  circle.setAttribute("cx", cp.x);
  circle.setAttribute("cy", cp.y);
  circle.dataset.radiusPx = isCurrent ? "8" : "6.5";
  circle.dataset.checkpointIndex = String(index);
  circle.setAttribute(
    "class",
    isCurrent ? "cn-checkpoint-current" : isDestination ? "cn-checkpoint-destination" : "cn-checkpoint-dot"
  );
  circle.addEventListener("click", () => reachCheckpoint(index));
  group.appendChild(circle);

  const number = document.createElementNS(SVG_NS, "text");
  number.setAttribute("x", cp.x);
  number.setAttribute("y", cp.y);
  number.dataset.fontPx = "7.5";
  number.setAttribute(
    "class",
    `cn-checkpoint-number${isCurrent ? " current" : ""}${isDestination ? " destination" : ""}`
  );
  number.textContent = String(cp.checkpoint);
  group.appendChild(number);

  if (isCurrent) {
    const label = document.createElementNS(SVG_NS, "text");
    label.setAttribute("x", cp.x);
    label.setAttribute("y", cp.y);
    label.dataset.fontPx = "10";
    label.dataset.offsetXPx = "13";
    label.dataset.offsetYPx = "-12";
    label.dataset.anchorX = String(cp.x);
    label.dataset.anchorY = String(cp.y);
    label.setAttribute("class", "cn-location-label");
    label.textContent = "YOU";
    group.appendChild(label);
  }
}

function updateOverlayScale() {
  const svg = state.currentSvg;
  if (!svg) return;
  const unitsPerPx = getUnitsPerPixel();

  svg.querySelectorAll("#campusnav-route-overlay circle[data-radius-px]").forEach((circle) => {
    circle.setAttribute("r", Number(circle.dataset.radiusPx) * unitsPerPx);
  });
  svg.querySelectorAll("#campusnav-route-overlay text[data-font-px]").forEach((text) => {
    text.setAttribute("font-size", Number(text.dataset.fontPx) * unitsPerPx);
    if (text.dataset.anchorX) {
      const x = Number(text.dataset.anchorX) + Number(text.dataset.offsetXPx || 0) * unitsPerPx;
      const y = Number(text.dataset.anchorY) + Number(text.dataset.offsetYPx || 0) * unitsPerPx;
      text.setAttribute("x", x);
      text.setAttribute("y", y);
    }
  });
}

function getUnitsPerPixel() {
  if (!state.currentSvg || !state.viewBox) return 1;
  const rect = state.currentSvg.getBoundingClientRect();
  if (!rect.width) return 1;
  return state.viewBox.w / rect.width;
}

function getViewBox(svg) {
  const raw = svg.getAttribute("viewBox");
  if (raw) {
    const values = raw.trim().split(/[\s,]+/).map(Number);
    if (values.length === 4 && values.every(Number.isFinite)) {
      return { x: values[0], y: values[1], w: values[2], h: values[3] };
    }
  }
  const width = Number(svg.getAttribute("width")) || 1000;
  const height = Number(svg.getAttribute("height")) || 1400;
  return { x: 0, y: 0, w: width, h: height };
}

function applyViewBox() {
  if (!state.currentSvg || !state.viewBox) return;
  const v = state.viewBox;
  state.currentSvg.setAttribute("viewBox", `${v.x} ${v.y} ${v.w} ${v.h}`);
  requestAnimationFrame(updateOverlayScale);
}

function fitMap() {
  if (!state.originalViewBox) return;
  state.viewBox = { ...state.originalViewBox };
  applyViewBox();
}

function zoomMap(factor, clientX = null, clientY = null) {
  if (!state.viewBox || !state.originalViewBox || !state.currentSvg) return;
  const rect = state.currentSvg.getBoundingClientRect();
  const px = clientX == null ? 0.5 : Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
  const py = clientY == null ? 0.5 : Math.max(0, Math.min(1, (clientY - rect.top) / rect.height));
  const v = state.viewBox;
  const anchorX = v.x + px * v.w;
  const anchorY = v.y + py * v.h;
  const newW = v.w * factor;
  const newH = v.h * factor;
  const minW = state.originalViewBox.w / 7;
  const maxW = state.originalViewBox.w * 1.4;
  if (newW < minW || newW > maxW) return;
  state.viewBox = {
    x: anchorX - px * newW,
    y: anchorY - py * newH,
    w: newW,
    h: newH,
  };
  applyViewBox();
}

function centerOnCheckpoint(cp) {
  if (!cp || !state.originalViewBox) return;
  const displayPoint = sourcePointToDisplay(cp.x, cp.y);
  const zoom = 2.55;
  const w = state.originalViewBox.w / zoom;
  const h = state.originalViewBox.h / zoom;
  state.viewBox = {
    x: displayPoint.x - w / 2,
    y: displayPoint.y - h / 2,
    w,
    h,
  };
  applyViewBox();
}

function panStart(event) {
  if (!state.currentSvg || !state.viewBox) return;
  if (event.target.closest?.("#campusnav-route-overlay")?.querySelector?.("[data-checkpoint-index]")) return;
  state.dragging = true;
  state.dragStart = {
    clientX: event.clientX,
    clientY: event.clientY,
    viewBox: { ...state.viewBox },
  };
  els.mapViewport.setPointerCapture?.(event.pointerId);
}

function panMove(event) {
  if (!state.dragging || !state.dragStart || !state.currentSvg) return;
  const rect = state.currentSvg.getBoundingClientRect();
  if (!rect.width || !rect.height) return;
  const dx = ((event.clientX - state.dragStart.clientX) / rect.width) * state.dragStart.viewBox.w;
  const dy = ((event.clientY - state.dragStart.clientY) / rect.height) * state.dragStart.viewBox.h;
  state.viewBox = {
    ...state.dragStart.viewBox,
    x: state.dragStart.viewBox.x - dx,
    y: state.dragStart.viewBox.y - dy,
  };
  applyViewBox();
}

function panEnd(event) {
  state.dragging = false;
  state.dragStart = null;
  els.mapViewport.releasePointerCapture?.(event.pointerId);
}

function openBlockedDialog() {
  els.blockedDialog.querySelectorAll(".blocked-grid input").forEach((input) => {
    input.checked = state.blocked.has(input.value);
  });
  els.blockedDialog.showModal();
}

function routingCodeForCheckpoint(cp) {
  if (!cp) return "";
  const candidates = state.floorRouteIndexes?.[cp.floor_id] || [];
  const match = candidates.find((point) => point.globalIndex === cp.path_index);
  return match?.original_node_id || cp.node_id;
}

async function rerouteFromCurrentCheckpoint() {
  if (!state.route || !state.lastPlan) return;
  const selected = [...els.blockedDialog.querySelectorAll(".blocked-grid input:checked")].map((input) => input.value);
  if (!selected.length) {
    showToast("Choose at least one blocked connector");
    return;
  }
  selected.forEach((item) => state.blocked.add(item));
  const cp = state.route.checkpoints[state.currentCheckpointIndex];
  els.blockedDialog.close();

  await planRoute({
    start: {
      kind: "location",
      floor_id: cp.floor_id,
      code: routingCodeForCheckpoint(cp),
      name: cp.label,
      type: "checkpoint",
    },
    destination: state.lastPlan.destination,
    mode: state.lastPlan.mode,
    blocked: [...state.blocked],
  });
  showToast("Alternate route calculated from your current point");
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

boot();
