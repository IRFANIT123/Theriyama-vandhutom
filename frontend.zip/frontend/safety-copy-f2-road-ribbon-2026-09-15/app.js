/*
  CampusNav: DOM-only map presentation. Every backend route point is retained.
  Architectural geometry and routes share one display transform.
*/
const API_BASE = "http://127.0.0.1:8000";
const INKSCAPE_NS = "http://www.inkscape.org/namespaces/inkscape";
const SVG_NS = "http://www.w3.org/2000/svg";

const CORRIDOR_NODE_MATCH_TOLERANCE = 4.0;

const state = {
  floors: [],
  maps: new Map(),
  entrances: [],
  locations: [],
  locationsByFloor: new Map(),
  selectedStart: null,
  selectedDestination: null,
  route: null,
  lastPlan: null,
  blocked: new Set(),
  currentCheckpointIndex: 0,
  selectedFloor: "G",
  floorRouteIndexes: {},
  currentSvg: null,
  originalViewBox: null,
  viewBox: null,
  dragging: false,
  dragStart: null,
  suggestionItems: { start: [], destination: [] },
  sourceViewBox: null,
  rotationGroup: null,
  mapLoadVersion: 0,
  progressBusy: false,
  routeDisplayStart: "",
};

const $ = (id) => document.getElementById(id);
const els = {
  apiPill: $("apiPill"),
  gpsBtn: $("gpsBtn"),
  startSearch: $("startSearch"),
  startSuggestions: $("startSuggestions"),
  startSelection: $("startSelection"),
  clearStartBtn: $("clearStartBtn"),
  destinationSearch: $("destinationSearch"),
  destinationSuggestions: $("destinationSuggestions"),
  clearDestinationBtn: $("clearDestinationBtn"),
  exitChooser: $("exitChooser"),
  exitButtons: $("exitButtons"),
  navigateBtn: $("navigateBtn"),
  formMessage: $("formMessage"),
  routeSummary: $("routeSummary"),
  summaryRouteText: $("summaryRouteText"),
  summaryMode: $("summaryMode"),
  summaryCost: $("summaryCost"),
  summaryFloors: $("summaryFloors"),
  progressPercent: $("progressPercent"),
  progressFill: $("progressFill"),
  currentLandmark: $("currentLandmark"),
  remainingText: $("remainingText"),
  clearRouteBtn: $("clearRouteBtn"),
  currentFloorTitle: $("currentFloorTitle"),
  floorButtons: $("floorButtons"),
  zoomOutBtn: $("zoomOutBtn"),
  zoomInBtn: $("zoomInBtn"),
  fitBtn: $("fitBtn"),
  mapViewport: $("mapViewport"),
  mapLoading: $("mapLoading"),
  svgHost: $("svgHost"),
  floatingNavControls: $("floatingNavControls"),
  previousCheckpointBtn: $("previousCheckpointBtn"),
  centerMeBtn: $("centerMeBtn"),
  stepBar: $("stepBar"),
  nextStepTitle: $("nextStepTitle"),
  nextStepSubtitle: $("nextStepSubtitle"),
  reportBlockedBtn: $("reportBlockedBtn"),
  currentStepCard: $("currentStepCard"),
  currentStepTitle: $("currentStepTitle"),
  currentStepFloor: $("currentStepFloor"),
  routeInstructionsCard: $("routeInstructionsCard"),
  routeInstructions: $("routeInstructions"),
  instructionCount: $("instructionCount"),
  blockedDialog: $("blockedDialog"),
  applyBlockedBtn: $("applyBlockedBtn"),
  toast: $("toast"),
};

async function api(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, options);
  if (!response.ok) {
    let detail = `${response.status} ${response.statusText}`;
    try {
      const body = await response.json();
      detail = body.detail || detail;
    } catch (_) {}
    throw new Error(detail);
  }
  const contentType = response.headers.get("content-type") || "";
  return contentType.includes("application/json") ? response.json() : response.text();
}

async function boot() {
  bindEvents();
  try {
    const health = await api("/health");
    setApiStatus(true, "Loading building…");

    const [floors, maps, entrances] = await Promise.all([
      api("/floors"),
      api("/maps"),
      api("/entrances"),
    ]);

    state.floors = floors;
    state.entrances = entrances;
    maps.forEach((m) => state.maps.set(m.floor_id, m));

    const locationLists = await Promise.all(
      floors.map(async (f) => {
        const rows = await api(`/locations?floor_id=${encodeURIComponent(f.floor_id)}`);
        state.locationsByFloor.set(f.floor_id, rows);
        return rows;
      })
    );
    state.locations = locationLists.flat();
    els.startSearch.disabled = false;
    els.destinationSearch.disabled = false;
    setApiStatus(true, `Online · ${health.floors} floors`);

    renderExitChoices();
    renderFloorButtons();
    await loadFloorMap("G", true);
  } catch (error) {
    console.error(error);
    setApiStatus(false, "Backend offline");
    showFormError(
      "CampusNav could not connect to FastAPI. Start it with: python -m uvicorn backend.main:app --reload"
    );
  }
}

function bindEvents() {
  bindSmartSearch("start", els.startSearch, els.startSuggestions);
  bindSmartSearch("destination", els.destinationSearch, els.destinationSuggestions);

  els.clearStartBtn.addEventListener("click", () => clearSelection("start"));
  els.clearDestinationBtn.addEventListener("click", () => clearSelection("destination"));
  els.gpsBtn.addEventListener("click", useGps);
  els.navigateBtn.addEventListener("click", () => planRoute());
  els.clearRouteBtn.addEventListener("click", clearRoute);
  els.previousCheckpointBtn.addEventListener("click", previousCheckpoint);
  els.centerMeBtn.addEventListener("click", centerCurrentCheckpoint);
  $("confirmNextBtn").addEventListener("click", () => reachCheckpoint(state.currentCheckpointIndex + 1));
  new ResizeObserver(() => requestAnimationFrame(updateOverlayScale)).observe(els.svgHost);
  els.zoomInBtn.addEventListener("click", () => zoomMap(0.82));
  els.zoomOutBtn.addEventListener("click", () => zoomMap(1.22));
  els.fitBtn.addEventListener("click", fitMap);

  els.mapViewport.addEventListener(
    "wheel",
    (event) => {
      event.preventDefault();
      zoomMap(event.deltaY < 0 ? 0.88 : 1.14, event.clientX, event.clientY);
    },
    { passive: false }
  );
  els.mapViewport.addEventListener("pointerdown", panStart);
  els.mapViewport.addEventListener("pointermove", panMove);
  els.mapViewport.addEventListener("pointerup", panEnd);
  els.mapViewport.addEventListener("pointercancel", panEnd);

  els.reportBlockedBtn.addEventListener("click", openBlockedDialog);
  els.applyBlockedBtn.addEventListener("click", (event) => {
    event.preventDefault();
    rerouteFromCurrentCheckpoint();
  });

  document.querySelectorAll(".avoid-buttons input").forEach((input) => {
    input.addEventListener("change", () => {
      if (input.checked) state.blocked.add(input.value);
      else state.blocked.delete(input.value);
      renderBlockedStatus();
    });
  });

  document.addEventListener("click", (event) => {
    if (!event.target.closest(".smart-search")) {
      hideSuggestions("start");
      hideSuggestions("destination");
    }
  });
}

function setApiStatus(ok, message) {
  els.apiPill.classList.toggle("online", ok);
  els.apiPill.classList.toggle("offline", !ok);
  els.apiPill.querySelector("span:last-child").textContent = message;
}

function showToast(message) {
  els.toast.textContent = message;
  els.toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => els.toast.classList.remove("show"), 2400);
}

function showFormError(message) {
  els.formMessage.hidden = false;
  els.formMessage.textContent = message;
}

function clearFormError() {
  els.formMessage.hidden = true;
  els.formMessage.textContent = "";
}

function selectedMode() {
  return document.querySelector('input[name="mode"]:checked')?.value || "lift";
}

function floorName(floorId) {
  return state.floors.find((f) => f.floor_id === floorId)?.name || floorId;
}

function humanize(value) {
  return String(value || "")
    .replaceAll("_", " ")
    .replace(/\b\w/g, (m) => m.toUpperCase());
}

function normalizeText(value) {
  return String(value || "").trim().toLowerCase();
}

function friendlyCode(value) {
  return String(value || "")
    .replace(/ENTRANCE([12])(?:-G)?/gi, "Entrance $1")
    .replace(/LIFT(\d+)(?:-[A-Z0-9]+)?/gi, "Lift $1")
    .replace(/STAIRS?(\d+)(?:-[A-Z0-9-]+)?/gi, "Stair $1")
    .replace(/\b(?:F\d+[_-])?(?:C\d+|F\d+C\d+|circle\d+|ellipse\d+j?)\b/gi, "confirmed point");
}

function displayLocation(item) {
  if (item.isEntrance || /entrance/i.test(item.type || "")) return friendlyCode(item.code);
  const name = item.name && item.name !== item.code ? ` · ${item.name}` : "";
  return `${friendlyCode(item.code)}${name}`;
}

function renderBlockedStatus() {
  const selected = [...state.blocked].map(friendlyCode);
  $("blockedStatus").hidden = !selected.length;
  $("blockedStatus").textContent = selected.length ? `Unavailable: ${selected.join(" · ")}` : "";
  document.querySelectorAll(".avoid-buttons input").forEach(input => { input.checked=state.blocked.has(input.value); });
}

function locationIcon(type) {
  const t = normalizeText(type);
  if (/toilet|bathroom|washroom|wc/.test(t)) return "🚻";
  if (/lab/.test(t)) return "⚗";
  if (/faculty|office/.test(t)) return "▣";
  if (/entrance|exit/.test(t)) return "↗";
  return "□";
}

function bindSmartSearch(kind, input, suggestions) {
  input.addEventListener("keydown", event => {
    if (event.key === "Escape") hideSuggestions(kind);
    if (event.key === "ArrowDown" && !suggestions.hidden) {
      event.preventDefault();
      suggestions.querySelector("button")?.focus();
    }
    if (event.key === "Enter" && !suggestions.hidden && state.suggestionItems[kind].length === 1) {
      event.preventDefault();
      chooseLocation(kind, state.suggestionItems[kind][0]);
    }
  });
  input.addEventListener("input", () => {
    clearFormError();
    if (kind === "start") {
      state.selectedStart = null;
      els.startSelection.hidden = true;
    }
    else state.selectedDestination = null;

    const query = input.value.trim();
    if (kind === "destination") {
      const wantsExit = /(^|\s)exit(\s|$)/i.test(query) || /^leave\b/i.test(query);
      els.exitChooser.hidden = !wantsExit;
      if (wantsExit) {
        hideSuggestions("destination");
        return;
      }
    }
    renderSuggestions(kind, query, suggestions);
  });

  input.addEventListener("focus", () => {
    const query = input.value.trim();
    if (kind === "destination" && /(^|\s)exit(\s|$)/i.test(query)) {
      els.exitChooser.hidden = false;
      return;
    }
    renderSuggestions(kind, query, suggestions);
  });
}

function renderSuggestions(kind, query, container) {
  const q = normalizeText(query);
  let pool = [...state.locations];

  if (kind === "start") {
    const entranceItems = state.entrances.map((e) => ({
      floor_id: "G",
      code: e.original_node_id,
      name: `${e.label} · Entrance`,
      type: "entrance",
      isEntrance: true,
    }));
    pool = [...entranceItems, ...pool];
  }

  let results = pool.filter((item) => {
    if (!q) return kind === "start" ? item.floor_id === "G" : false;
    const haystack = normalizeText(`${item.code} ${item.name || ""} ${item.type || ""} ${item.floor_id || ""}`);
    return haystack.includes(q);
  });

  results = results.slice(0, 12);
  state.suggestionItems[kind] = results;

  if (!results.length) {
    if (!q) {
      container.hidden = true;
      return;
    }
    container.innerHTML = `<div class="suggestion-empty">No matching location found.</div>`;
    container.hidden = false;
    return;
  }

  container.innerHTML = results
    .map(
      (item, index) => `
        <button class="suggestion-item" type="button" data-kind="${kind}" data-index="${index}">
          <span class="suggestion-icon">${escapeHtml(locationIcon(item.type))}</span>
          <span class="suggestion-copy">
            <strong>${escapeHtml(displayLocation(item))}</strong>
            <span>${escapeHtml(item.floor_id)} · ${escapeHtml(humanize(item.type || "location"))}</span>
          </span>
        </button>`
    )
    .join("");
  container.hidden = false;

  container.querySelectorAll(".suggestion-item").forEach((button) => {
    button.addEventListener("click", () => {
      const item = state.suggestionItems[kind][Number(button.dataset.index)];
      chooseLocation(kind, item);
    });
  });
}

function chooseLocation(kind, item) {
  if (!item) return;
  const selection = {
    kind: "location",
    floor_id: item.floor_id,
    code: item.code,
    name: item.name || item.code,
    type: item.type || "location",
  };

  if (kind === "start") {
    state.selectedStart = selection;
    els.startSearch.value = `${friendlyCode(item.code)} · ${floorName(item.floor_id)}`;
    els.startSelection.hidden = false;
    els.startSelection.textContent = `Start confirmed: ${friendlyCode(item.code)} on ${floorName(item.floor_id)}`;
    hideSuggestions("start");
  } else {
    state.selectedDestination = selection;
    els.destinationSearch.value = `${friendlyCode(item.code)} · ${floorName(item.floor_id)}`;
    els.exitChooser.hidden = true;
    hideSuggestions("destination");
  }
}

function clearSelection(kind) {
  if (kind === "start") {
    state.selectedStart = null;
    els.startSearch.value = "";
    els.startSelection.hidden = true;
    els.startSearch.focus();
  } else {
    state.selectedDestination = null;
    els.destinationSearch.value = "";
    els.exitChooser.hidden = true;
    renderExitChoices();
    els.destinationSearch.focus();
  }
}

function hideSuggestions(kind) {
  const el = kind === "start" ? els.startSuggestions : els.destinationSuggestions;
  el.hidden = true;
}

function renderExitChoices() {
  const options = [
    {
      mode: "nearest",
      code: "EXIT",
      label: "Nearest available exit",
      description: "CampusNav chooses the best exit for your current route.",
    },
    ...state.entrances.map((e) => ({
      mode: "specific",
      code: e.original_node_id,
      label: `Exit via ${e.label}`,
      description: "Ground Floor · building entrance and exit",
    })),
  ];

  els.exitButtons.innerHTML = options
    .map(
      (option, index) => `
        <button class="exit-choice-btn" type="button" data-exit-index="${index}">
          <span>
            <strong>${escapeHtml(option.label)}</strong>
            <small>${escapeHtml(option.description)}</small>
          </span>
          <span class="exit-arrow">→</span>
        </button>`
    )
    .join("");

  els.exitButtons.querySelectorAll(".exit-choice-btn").forEach((button) => {
    button.addEventListener("click", () => {
      const option = options[Number(button.dataset.exitIndex)];
      state.selectedDestination = {
        kind: "exit",
        exitMode: option.mode,
        floor_id: "G",
        code: option.code,
        name: option.label,
        type: "exit",
      };
      els.destinationSearch.value = option.label;
      els.exitButtons.querySelectorAll(".exit-choice-btn").forEach((b) => b.classList.remove("selected"));
      button.classList.add("selected");
      showToast(`${option.label} selected`);
    });
  });
}

async function useGps() {
  clearFormError();
  if (!navigator.geolocation) {
    showFormError("This browser does not provide geolocation. Choose a start location manually.");
    return;
  }

  els.gpsBtn.disabled = true;
  els.gpsBtn.querySelector("span:last-child").textContent = "Finding nearest entrance…";

  navigator.geolocation.getCurrentPosition(
    async (position) => {
      try {
        const { latitude, longitude, accuracy } = position.coords;
        const result = await api(
          `/nearest-entrance?latitude=${encodeURIComponent(latitude)}&longitude=${encodeURIComponent(longitude)}&accuracy_m=${encodeURIComponent(accuracy || 0)}`
        );
        const entrance = result.nearest_entrance;
        state.selectedStart = {
          kind: "location",
          floor_id: "G",
          code: entrance.node_id,
          name: entrance.label,
          type: "entrance",
        };
        els.startSearch.value = `${entrance.label} · GPS detected`;
        els.startSelection.hidden = false;
        els.startSelection.textContent = `${result.message} Distance: about ${Number(entrance.distance_m || 0).toFixed(1)} m.`;
        showToast(`Nearest entrance: ${entrance.label}`);
      } catch (error) {
        showFormError(error.message);
      } finally {
        els.gpsBtn.disabled = false;
        els.gpsBtn.querySelector("span:last-child").textContent = "Use outdoor GPS";
      }
    },
    (error) => {
      els.gpsBtn.disabled = false;
      els.gpsBtn.querySelector("span:last-child").textContent = "Use outdoor GPS";
      showFormError(
        error.code === 1
          ? "Location permission was denied. Choose your entrance/start point manually."
          : "GPS position could not be read. Try again outside near the building."
      );
    },
    { enableHighAccuracy: true, timeout: 12000, maximumAge: 5000 }
  );
}

function collectBlocked(extra = []) {
  const result = new Set(state.blocked);
  document.querySelectorAll(".avoid-buttons input:checked").forEach((input) => result.add(input.value));
  extra.forEach((item) => item && result.add(item));
  result.delete("STRING");
  return [...result];
}

function appendBlocked(params, blocked) {
  blocked.forEach((item) => params.append("blocked", item));
}

async function planRoute(overrides = {}) {
  clearFormError();

  const start = overrides.start || state.selectedStart;
  const destination = overrides.destination || state.selectedDestination;
  const mode = overrides.mode || selectedMode();
  const blocked = collectBlocked(overrides.blocked || []);

  if (!start) {
    showFormError("Choose your current room/start point, or use outdoor GPS.");
    return;
  }
  if (!destination) {
    showFormError('Choose a destination. You can also type "exit" to choose an exit.');
    return;
  }

  els.navigateBtn.disabled = true;
  els.navigateBtn.querySelector("span:first-child").textContent = "Finding your route…";

  try {
    const params = new URLSearchParams({
      start_floor: start.floor_id,
      start: start.code,
      mode,
    });
    appendBlocked(params, blocked);

    let route;
    if (destination.kind === "exit" && destination.exitMode === "nearest") {
      route = await api(`/route-to-exit?${params.toString()}`);
    } else {
      params.set("destination_floor", destination.floor_id);
      params.set("destination", destination.code);
      route = await api(`/route?${params.toString()}`);
    }

    state.route = route;
    state.routeDisplayStart = start.type === "checkpoint" ? friendlyCode(start.name) : friendlyCode(start.code);
    state.blocked = new Set((route.blocked || []).filter((x) => x && x !== "STRING"));
    state.currentCheckpointIndex = 0;
    renderBlockedStatus();
    state.selectedFloor = route.floors[0];
    state.lastPlan = {
      destination: { ...destination },
      mode,
    };

    buildGlobalPathIndexes();
    renderRouteSummary();
    renderInstructions();
    renderFloorButtons();
    updateProgressUi();
    els.routeSummary.hidden = false;
    els.floatingNavControls.hidden = false;
    els.stepBar.hidden = false;
    els.currentStepCard.hidden = false;
    els.routeInstructionsCard.hidden = false;

    await loadFloorMap(state.selectedFloor, true);
    centerCurrentCheckpoint();
    if (window.matchMedia("(max-width:760px)").matches) {
      els.mapViewport.scrollIntoView({
        block: "center",
        behavior: window.matchMedia("(prefers-reduced-motion:reduce)").matches ? "auto" : "smooth",
      });
    }
    showToast("Route ready — tap route dots as you reach them");
  } catch (error) {
    console.error(error);
    showFormError(error.message);
  } finally {
    els.navigateBtn.disabled = false;
    els.navigateBtn.querySelector("span:first-child").textContent = "Start navigation";
  }
}

function renderRouteSummary() {
  const r = state.route;
  if (!r) return;
  const destinationLabel = r.destination === "EXIT" && r.chosen_exit ? r.chosen_exit.label : r.destination;
  els.summaryRouteText.textContent = `${state.routeDisplayStart || friendlyCode(r.start)} → ${friendlyCode(destinationLabel)}`;
  els.summaryMode.textContent = humanize(r.mode);
  els.summaryCost.textContent = `${r.total_cost} m`;
  els.summaryFloors.textContent = r.floors.join(" → ");
}

function buildGeometryDirections() {
  const output = [];
  const route = state.route;
  if (!route) return output;

  for (const floor of route.floors || []) {
    const points = route.floor_routes?.[floor] || [];
    if (points.length < 3) continue;

    for (let i = 1; i < points.length - 1; i++) {
      const a = points[i - 1], b = points[i], c = points[i + 1];
      const v1x = b.x - a.x, v1y = b.y - a.y;
      const v2x = c.x - b.x, v2y = c.y - b.y;
      const l1 = Math.hypot(v1x, v1y), l2 = Math.hypot(v2x, v2y);
      if (l1 < 0.001 || l2 < 0.001) continue;

      const dot = (v1x * v2x + v1y * v2y) / (l1 * l2);
      const angle = Math.acos(Math.max(-1, Math.min(1, dot))) * 180 / Math.PI;
      if (angle < 38) continue;

      // SVG coordinates have +Y downward. Positive cross therefore represents
      // a clockwise/right turn on the displayed floor. A 90° rotation preserves
      // handedness, so the same left/right remains valid after display rotation.
      const cross = v1x * v2y - v1y * v2x;
      const direction = cross > 0 ? "right" : "left";
      const pathIndex = state.floorRouteIndexes?.[floor]?.[i]?.globalIndex;
      const nearby = (route.checkpoints || []).find(
        (cp) => cp.floor_id === floor && Math.abs((cp.path_index ?? -999) - pathIndex) <= 2
      );
      const context = nearby && !/^Route checkpoint$/i.test(nearby.label || "")
        ? ` near ${String(nearby.label).replace(/^Near\s+/i, "")}`
        : "";
      output.push({
        type: "turn",
        floor,
        text: `Turn ${direction}${context} and continue along the corridor`,
        pathIndex: Number.isFinite(pathIndex) ? pathIndex : i,
      });
    }
  }
  return output;
}

function renderInstructions() {
  const route = state.route;
  if (!route) return;

  const backend = (route.instructions || [])
    .filter((item) => item.type !== "start")
    .map((item) => ({ ...item, source: "backend" }));
  const turns = buildGeometryDirections().map((item) => ({ ...item, source: "geometry" }));

  const items = [];
  items.push({ type: "start", floor: route.floors?.[0] || "", text: `Start at ${state.routeDisplayStart || friendlyCode(route.start)}` });

  // Keep backend connector/floor-change instructions authoritative. Add only
  // significant geometric turns; no route geometry is altered by this wording.
  for (const floor of route.floors || []) {
    turns
      .filter((item) => item.floor === floor)
      .sort((a, b) => a.pathIndex - b.pathIndex)
      .forEach((item) => items.push(item));

    backend
      .filter((item) => (item.floor || item.from_floor || item.to_floor) === floor)
      .forEach((item) => items.push(item));
  }

  // Some final backend instructions may not match the simple floor filter.
  backend.forEach((item) => {
    if (!items.some((x) => x.text === item.text)) items.push(item);
  });

  const cleaned = items.filter(
    (item, index, arr) => index === 0 || item.text !== arr[index - 1].text
  );

  els.instructionCount.textContent = `${cleaned.length} step${cleaned.length === 1 ? "" : "s"}`;
  els.routeInstructions.innerHTML = cleaned
    .map((item, index) => `
      <div class="instruction-item">
        <span class="instruction-number">${index + 1}</span>
        <span class="instruction-copy">
          <strong>${escapeHtml(friendlyCode(item.text))}</strong>
          <span>${escapeHtml(item.floor || item.to_floor || "")}</span>
        </span>
      </div>`)
    .join("");
}

function buildGlobalPathIndexes() {
  state.floorRouteIndexes = {};
  if (!state.route) return;
  const raw = state.route.raw_node_path || [];
  let cursor = 0;

  for (const floor of state.route.floors || []) {
    const points = state.route.floor_routes?.[floor] || [];
    state.floorRouteIndexes[floor] = [];
    for (const point of points) {
      let found = -1;
      for (let i = cursor; i < raw.length; i++) {
        if (raw[i] === point.node_id) {
          found = i;
          cursor = i + 1;
          break;
        }
      }
      state.floorRouteIndexes[floor].push({ ...point, globalIndex: found });
    }
  }
}

function renderFloorButtons() {
  const floors = state.floors.map((f) => f.floor_id);
  els.floorButtons.innerHTML = floors
    .map(
      (floor) => `
        <button class="floor-button ${floor === state.selectedFloor ? "active" : ""}" type="button" data-floor="${escapeHtml(floor)}" aria-pressed="${floor === state.selectedFloor}" aria-label="${escapeHtml(floorName(floor))}">
          <strong>${escapeHtml(floor)}</strong>
          <span>${escapeHtml(shortFloorName(floorName(floor)))}</span>
        </button>`
    )
    .join("");

  els.floorButtons.querySelectorAll(".floor-button").forEach((button) => {
    button.addEventListener("click", async () => {
      state.selectedFloor = button.dataset.floor;
      renderFloorButtons();
      await loadFloorMap(state.selectedFloor, true);
    });
  });
}

function shortFloorName(name) {
  return String(name).replace(/ floor/i, "");
}

function updateProgressUi() {
  if (!state.route?.checkpoints?.length) return;
  const cp = state.route.checkpoints[state.currentCheckpointIndex];
  const next = state.route.checkpoints[state.currentCheckpointIndex + 1];
  const progress = Number(cp.progress_percent || 0);

  els.progressPercent.textContent = `${progress}%`;
  els.progressFill.style.width = `${Math.max(0, Math.min(100, progress))}%`;
  els.currentLandmark.textContent = friendlyCode(cp.label);
  els.remainingText.textContent = `${cp.remaining_distance_m} m remaining`;
  els.previousCheckpointBtn.disabled = state.currentCheckpointIndex <= 0 || state.progressBusy;
  $("confirmNextBtn").disabled = !next || state.progressBusy;
  $("confirmNextBtn").textContent = next ? "I reached this point" : "Arrived";
  $("journeyProgress").setAttribute("aria-valuenow", Math.max(0, Math.min(100, progress)));

  els.currentStepTitle.textContent = friendlyCode(cp.label);
  els.currentStepFloor.textContent = `${floorName(cp.floor_id)} · manually confirmed checkpoint`;

  if (next) {
    els.nextStepTitle.textContent = friendlyCode(next.label);
    els.nextStepSubtitle.textContent = next.floor_id==="F2"
      ? `${floorName(next.floor_id)} · confirm point ${next.checkpoint} only after you physically reach it`
      : `${floorName(next.floor_id)} · tap dot ${next.checkpoint} only after you physically reach it`;
  } else {
    els.nextStepTitle.textContent = "Destination reached";
    els.nextStepSubtitle.textContent = "Navigation complete";
  }
}

async function reachCheckpoint(index) {
  if (state.progressBusy || !state.route?.checkpoints?.[index] || index <= state.currentCheckpointIndex) return;
  if (index > state.currentCheckpointIndex + 1) {
    showToast("Confirm checkpoints in order — tap the next dot first");
    return;
  }

  state.progressBusy = true;
  state.currentCheckpointIndex = index;
  const cp = state.route.checkpoints[index];
  const next = state.route.checkpoints[index + 1];

  updateProgressUi();

  // Cross-floor hand-off:
  // Once the user confirms the connector checkpoint (lift/stairs) on the
  // current floor, immediately display the next routed floor. Previously the
  // app stayed on the old floor, while the next tappable checkpoint existed
  // only on the new floor, which trapped navigation at the connector.
  const hasFloorTransition = Boolean(next && next.floor_id && next.floor_id !== cp.floor_id);
  const displayFloor = hasFloorTransition ? next.floor_id : cp.floor_id;

  state.selectedFloor = displayFloor;
  renderFloorButtons();
  if (state.currentSvg && displayFloor === state.currentSvg.dataset.floor) drawRouteOverlay();
  else await loadFloorMap(displayFloor, false);

  if (hasFloorTransition) {
    // Center on the next floor's arrival checkpoint so the user sees where
    // to continue after exiting the lift/stairs. Progress still remains at
    // the last manually confirmed checkpoint until that next dot is tapped.
    focusRemainingRoute(next);
    showToast(`Take the ${connectorWord(cp, next)} to ${floorName(next.floor_id)} · the map has switched automatically`);
  } else {
    focusRemainingRoute(cp);
    showToast(
      index === state.route.checkpoints.length - 1
        ? "Destination reached"
        : `Progress updated · ${cp.progress_percent}%`
    );
  }
  state.progressBusy = false;
  updateProgressUi();
}

function connectorWord(cp, next) {
  const text = `${cp?.label || ""} ${next?.label || ""}`.toLowerCase();
  if (text.includes("stair")) return "stairs";
  if (text.includes("lift") || text.includes("elevator")) return "lift";
  return "connector";
}

async function previousCheckpoint() {
  if (state.progressBusy || !state.route || state.currentCheckpointIndex <= 0) return;
  state.progressBusy = true;
  state.currentCheckpointIndex -= 1;
  const cp = state.route.checkpoints[state.currentCheckpointIndex];
  state.selectedFloor = cp.floor_id;
  renderFloorButtons();
  updateProgressUi();
  if (state.currentSvg && cp.floor_id === state.currentSvg.dataset.floor) drawRouteOverlay();
  else await loadFloorMap(cp.floor_id, false);
  focusRemainingRoute(cp);
  state.progressBusy = false;
  updateProgressUi();
  showToast("Moved back to the previous checkpoint");
}

function centerCurrentCheckpoint() {
  const cp = state.route?.checkpoints?.[state.currentCheckpointIndex];
  if (cp && cp.floor_id === state.selectedFloor) centerOnCheckpoint(cp);
  else if (cp) {
    state.selectedFloor = cp.floor_id;
    renderFloorButtons();
    loadFloorMap(cp.floor_id, false).then(() => centerOnCheckpoint(cp));
  }
}

function clearRoute() {
  state.route = null;
  state.lastPlan = null;
  state.currentCheckpointIndex = 0;
  state.blocked.clear();
  renderBlockedStatus();
  state.floorRouteIndexes = {};
  els.routeSummary.hidden = true;
  els.floatingNavControls.hidden = true;
  els.stepBar.hidden = true;
  els.currentStepCard.hidden = true;
  els.routeInstructionsCard.hidden = true;
  if (state.currentSvg) state.currentSvg.querySelector("#campusnav-route-overlay")?.remove();
  document.querySelectorAll(".avoid-buttons input").forEach((input) => (input.checked = false));
  renderFloorButtons();
  showToast("Route cleared");
}

async function loadFloorMap(floorId, fitAfter = true) {
  const loadVersion = ++state.mapLoadVersion;
  state.selectedFloor = floorId;
  state.currentSvg = null;
  state.sourceViewBox = null;
  state.rotationGroup = null;
  renderFloorButtons();
  els.currentFloorTitle.textContent = `${floorId} · ${floorName(floorId)}`;
  els.mapLoading.innerHTML = `<div class="spinner"></div><span>Loading ${escapeHtml(floorName(floorId))}…</span>`;
  els.mapLoading.style.display = "grid";
  els.svgHost.innerHTML = "";

  try {
    const map = state.maps.get(floorId);
    if (!map?.url) throw new Error(`No SVG map is registered for ${floorId}.`);
    const svgText = await api(map.url);
    if (loadVersion !== state.mapLoadVersion) return;
    const doc = new DOMParser().parseFromString(svgText, "image/svg+xml");
    if (doc.querySelector("parsererror")) throw new Error(`${floorId} SVG could not be parsed.`);

    const svg = document.importNode(doc.documentElement, true);
    svg.removeAttribute("width");
    svg.removeAttribute("height");
    svg.setAttribute("preserveAspectRatio", "xMidYMid meet");
    svg.setAttribute("aria-label", `${floorName(floorId)} map`);
    const mapTitle = svg.querySelector("title");
    if (mapTitle) mapTitle.textContent = `${floorName(floorId)} · E Block`;
    els.svgHost.replaceChildren(svg);
    state.currentSvg = svg;
    svg.dataset.floor = floorId;

    // Decorate in the SVG's native coordinate system first. Then rotate the
    // complete rendered map in one shared group. Route coordinates remain in
    // their original backend/SVG coordinate system and therefore stay aligned.
    decorateBlueprint(svg, floorId);
    const rotatedViewBox = enableClockwiseMapRotation(svg);
    state.originalViewBox = mapContentViewBox(svg, rotatedViewBox);
    state.viewBox = { ...state.originalViewBox };
    applyViewBox();

    drawRouteOverlay();
    if (fitAfter) fitMap();
    els.mapLoading.style.display = "none";
  } catch (error) {
    if (loadVersion !== state.mapLoadVersion) return;
    console.error(error);
    els.mapLoading.innerHTML = `<span>${escapeHtml(error.message)}</span>`;
    els.mapLoading.style.display = "grid";
  }
}

function enableClockwiseMapRotation(svg) {
  // Frontend-only rotation. We do NOT touch the real SVG file or database.
  //
  // Source viewBox: (x0, y0, width, height)
  // 90° clockwise display mapping:
  //   x' = height + y0 - y
  //   y' = x - x0
  // The resulting display viewBox is 0 0 height width.
  const source = getViewBox(svg);
  state.sourceViewBox = { ...source };

  const group = document.createElementNS(SVG_NS, "g");
  group.id = "campusnav-clockwise-map";
  group.setAttribute(
    "transform",
    `matrix(0 1 -1 0 ${source.h + source.y} ${-source.x})`
  );

  // Keep non-rendered document resources at root level. Move every rendered
  // map element into the same group so blueprint, route, dots and arrows all
  // share exactly one transform.
  const rootOnly = new Set(["defs", "metadata", "title", "desc", "namedview"]);
  [...svg.childNodes].forEach((node) => {
    if (node.nodeType === 1 && rootOnly.has(String(node.localName || "").toLowerCase())) return;
    group.appendChild(node);
  });

  svg.appendChild(group);
  svg.setAttribute("viewBox", `0 0 ${source.h} ${source.w}`);
  state.rotationGroup = group;

  return { x: 0, y: 0, w: source.h, h: source.w };
}

function sourcePointToDisplay(x, y) {
  const source = state.sourceViewBox;
  if (!source) return { x, y };
  return {
    x: source.h + source.y - y,
    y: x - source.x,
  };
}


function decorateBlueprint(svg, floorId) {
  buildWholeFloorCorridorNetwork(svg, floorId);
  hideTechnicalGraph(svg);
  findLayer(svg, /map[\s_-]*walls/)?.classList.add("cn-architecture");
  colorInfrastructure(svg, floorId);
  colorRoomLabels(svg, floorId);
  raiseMapLabels(svg);
}

function layerToken(group) {
  return normalizeText(`${group?.id || ""} ${group?.getAttributeNS?.(INKSCAPE_NS,"label") || group?.getAttribute?.("inkscape:label") || ""}`);
}
function findLayer(svg, pattern) {
  return [...svg.querySelectorAll("g")].find(group=>pattern.test(layerToken(group))) || null;
}
function pointInRoot(element,x,y,svg) {
  const matrix=svg.getCTM()?.inverse().multiply(element.getCTM());
  return matrix ? new DOMPoint(x,y).matrixTransform(matrix) : null;
}
function collectNavNodes(layer,floorId,svg) {
  if (!layer) return [];
  return [...layer.querySelectorAll("circle,ellipse")].map(shape=>{
    const p=pointInRoot(shape,Number(shape.getAttribute("cx")),Number(shape.getAttribute("cy")),svg);
    return p ? {id:shape.id,x:p.x,y:p.y} : null;
  }).filter(Boolean);
}
function nearestNavNode(point,nodes) {
  let best=null,distance=Infinity;
  for (const node of nodes) {
    const d=Math.hypot(node.x-point.x,node.y-point.y);
    if (d<distance) {best=node;distance=d;}
  }
  return distance<=CORRIDOR_NODE_MATCH_TOLERANCE ? best : null;
}
function pointToSegmentDistance(p,a,b) {
  const dx=b.x-a.x,dy=b.y-a.y;
  const t=dx||dy ? Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/(dx*dx+dy*dy))) : 0;
  return Math.hypot(p.x-a.x-t*dx,p.y-a.y-t*dy);
}
function segmentClearance(a,b,c,d) {
  const cross=(p,q,r)=>(q.x-p.x)*(r.y-p.y)-(q.y-p.y)*(r.x-p.x);
  if (cross(a,b,c)*cross(a,b,d)<0 && cross(c,d,a)*cross(c,d,b)<0) return 0;
  return Math.min(pointToSegmentDistance(a,c,d),pointToSegmentDistance(b,c,d),
    pointToSegmentDistance(c,a,b),pointToSegmentDistance(d,a,b));
}
function buildWholeFloorCorridorNetwork(svg,floorId) {
  // F2 is the visual pilot; other floors retain their approved presentation.
  if (floorId === "F2") return buildF2CorridorSurface(svg);
  const nodeLayer=findLayer(svg,/nav[\s_-]*nodes/),edgeLayer=findLayer(svg,/nav[\s_-]*edges/),
    wallLayer=findLayer(svg,/map[\s_-]*walls/);
  if (!nodeLayer || !edgeLayer || !wallLayer) return;
  // Unknown node purposes and all room/connector spurs are excluded.
  const nodes=collectNavNodes(nodeLayer,floorId,svg);
  const width=Math.min(getViewBox(svg).w,getViewBox(svg).h)*.012;
  const destinationIds=new Set((state.locationsByFloor.get(floorId)||[]).map(item=>String(item.code)));
  findLayer(svg,/map[\s_-]*rooms/)?.querySelectorAll("text").forEach(label=>destinationIds.add(label.textContent.trim()));
  // Integrated metadata prefixes some identifiers; the source SVG retains
  // their unprefixed IDs. This affects presentation lookup only.
  const hallwayIds=new Set((window.CAMPUSNAV_HALLWAY_IDS?.[floorId]||[]).flatMap(id=>[
    id, id.startsWith(`${floorId}_`) ? id.slice(floorId.length+1) : id
  ]));
  const isHallway=id=>hallwayIds.has(id) && !destinationIds.has(id) && !/^(ENTRANCE|LIFT|STAIR)/i.test(id);
  const walls=[],sampleStep=width/5;
  for (const shape of wallLayer.querySelectorAll("path,line,polyline,polygon,rect")) {
    if (typeof shape.getTotalLength!=="function") continue;
    const length=shape.getTotalLength(),count=Math.max(1,Math.ceil(length/sampleStep));
    let previous=null;
    for (let i=0;i<=count;i++) {
      const p=shape.getPointAtLength(length*i/count),point=pointInRoot(shape,p.x,p.y,svg);
      if (point && previous) walls.push([previous,point]);
      previous=point;
    }
  }
  if (!walls.length) return;
  const accepted=[],adjacency=new Map();
  for (const edge of edgeLayer.querySelectorAll("path,line,polyline")) {
    if (typeof edge.getTotalLength!=="function") continue;
    const length=edge.getTotalLength(),p=edge.getPointAtLength(0),q=edge.getPointAtLength(length);
    const a=pointInRoot(edge,p.x,p.y,svg),b=pointInRoot(edge,q.x,q.y,svg);
    if (!a || !b || length<width/2) continue;
    const na=nearestNavNode(a,nodes),nb=nearestNavNode(b,nodes);
    if (!na || !nb || !isHallway(na.id) || !isHallway(nb.id)) continue;
    // Reject curved or multi-turn edges rather than inventing a straight shortcut.
    let straight=true;
    for (let i=1;i<8;i++) {
      const p=edge.getPointAtLength(length*i/8),v=pointInRoot(edge,p.x,p.y,svg);
      if (!v || pointToSegmentDistance(v,a,b)>width*.02) {straight=false;break;}
    }
    if (!straight) continue;
    const margin=width*.8;
    const nearby=walls.filter(([c,d])=>Math.max(c.x,d.x)>=Math.min(a.x,b.x)-margin &&
      Math.min(c.x,d.x)<=Math.max(a.x,b.x)+margin && Math.max(c.y,d.y)>=Math.min(a.y,b.y)-margin &&
      Math.min(c.y,d.y)<=Math.max(a.y,b.y)+margin);
    if (nearby.some(([c,d])=>segmentClearance(a,b,c,d)<margin)) continue;
    const index=accepted.length;
    accepted.push({a,b,na:na.id,nb:nb.id});
    for (const id of [na.id,nb.id]) {
      if(!adjacency.has(id))adjacency.set(id,[]);
      adjacency.get(id).push(index);
    }
  }
  if (!accepted.length) return;
  const group=document.createElementNS(SVG_NS,"g");
  group.id="campusnav-floor-corridors";
  group.setAttribute("aria-hidden","true");
  group.style.setProperty("--hallway-width",width);
  // Connected runs use restrained bevel joins. No junction discs or node circles.
  const visited=new Set();
  function trace(start,index) {
    const points=[];let id=start;
    while(!visited.has(index)) {
      visited.add(index);
      const e=accepted[index],forward=e.na===id;
      if(!points.length)points.push(forward?e.a:e.b);
      points.push(forward?e.b:e.a);
      id=forward?e.nb:e.na;
      const next=adjacency.get(id);
      if(next.length!==2)break;
      index=next.find(i=>!visited.has(i));
      if(index===undefined)break;
    }
    const road=document.createElementNS(SVG_NS,"polyline");
    road.setAttribute("points",points.map(p=>`${p.x},${p.y}`).join(" "));
    road.setAttribute("class","cn-hallway");
    group.appendChild(road);
  }
  for(const[id,edges]of adjacency)if(edges.length!==2)edges.forEach(i=>{if(!visited.has(i))trace(id,i);});
  accepted.forEach((e,i)=>{if(!visited.has(i))trace(e.na,i);});
  svg.insertBefore(group,wallLayer);
}

// The F2 blueprint uses straight M/L/H/V commands and collinear cubic
// commands. Retain command endpoints, including internal corridor bends.
// A genuinely curved/unsupported edge is left out, never straightened.
function blueprintEdgeVertices(edge, svg) {
  if (edge.localName === "line") return [
    pointInRoot(edge,Number(edge.getAttribute("x1")),Number(edge.getAttribute("y1")),svg),
    pointInRoot(edge,Number(edge.getAttribute("x2")),Number(edge.getAttribute("y2")),svg)
  ];
  if (edge.localName === "polyline") return [...edge.points].map(p=>pointInRoot(edge,p.x,p.y,svg));
  const tokens=(edge.getAttribute("d")||"").match(/[a-zA-Z]|[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?/g)||[];
  const result=[];let i=0,command="",p={x:0,y:0};
  while(i<tokens.length) {
    if(/^[a-z]$/i.test(tokens[i]))command=tokens[i++];
    const kind=command.toUpperCase(),relative=command!==kind;
    const count={M:2,L:2,H:1,V:1,C:6}[kind];
    if(!count || i+count>tokens.length)return [];
    const values=tokens.slice(i,i+count).map(Number);i+=count;
    if(!values.every(Number.isFinite))return [];
    const at=(x,y)=>({x:x+(relative?p.x:0),y:y+(relative?p.y:0)});
    let q;
    if(kind==="H")q={x:values[0]+(relative?p.x:0),y:p.y};
    else if(kind==="V")q={x:p.x,y:values[0]+(relative?p.y:0)};
    else if(kind==="C") {
      q=at(values[4],values[5]);
      if(pointToSegmentDistance(at(values[0],values[1]),p,q)>.05 ||
         pointToSegmentDistance(at(values[2],values[3]),p,q)>.05)return [];
    } else q=at(values[0],values[1]);
    p=q;result.push(pointInRoot(edge,p.x,p.y,svg));
    if(kind==="M")command=relative?"l":"L";
  }
  return result.filter(Boolean);
}

function buildF2CorridorSurface(svg) {
  const nodeLayer=findLayer(svg,/nav[\s_-]*nodes/),edgeLayer=findLayer(svg,/nav[\s_-]*edges/),
    wallLayer=findLayer(svg,/map[\s_-]*walls/),facilities=findLayer(svg,/map[\s_-]*infrastructure/);
  if(!nodeLayer||!edgeLayer||!wallLayer)return;
  const nodes=collectNavNodes(nodeLayer,"F2",svg);
  const hallwayIds=new Set((window.CAMPUSNAV_HALLWAY_IDS?.F2||[]).flatMap(id=>[id,id.replace(/^F2_/,"")]));
  const destinations=new Set((state.locationsByFloor.get("F2")||[]).map(l=>String(l.code)));
  const hallway=n=>n && hallwayIds.has(n.id) && !destinations.has(n.id) && !/^(LIFT|STAIR|ENTRANCE)/i.test(n.id);
  const walls=[];
  // Include facility boundaries: a corridor surface cannot flood a shaft/stair.
  for(const layer of [wallLayer,facilities].filter(Boolean)) {
    for(const shape of layer.querySelectorAll("path,line,polyline,polygon,rect")) {
      if(typeof shape.getTotalLength!=="function")continue;
      const length=shape.getTotalLength(),count=Math.max(1,Math.ceil(length/2));
      let previous=null;
      for(let j=0;j<=count;j++) {
        const p=shape.getPointAtLength(length*j/count),q=pointInRoot(shape,p.x,p.y,svg);
        if(previous&&q)walls.push([previous,q]);previous=q;
      }
    }
  }
  if(!walls.length)return;
  const maxHalfWidth=24,wallGap=3;
  const pieces=[],ends=new Map(),unsafeEdges=[];let accepted=0,excluded=0,narrowed=0;
  const cross=(a,b)=>a.x*b.y-a.y*b.x;
  function inside(point,polygon) {
    let sign=0;
    for(let j=0;j<polygon.length;j++) {
      const a=polygon[j],b=polygon[(j+1)%polygon.length];
      const c=cross({x:b.x-a.x,y:b.y-a.y},{x:point.x-a.x,y:point.y-a.y});
      if(Math.abs(c)<.0001)continue;
      if(sign&&Math.sign(c)!==sign)return false;sign=Math.sign(c);
    }
    return true;
  }
  function safe(polygon,nearby,gap=wallGap) {
    return !nearby.some(([a,b])=>inside(a,polygon)||inside(b,polygon)||
      polygon.some((p,j)=>segmentClearance(p,polygon[(j+1)%polygon.length],a,b)<gap-.1));
  }
  function addPolygon(polygon) {
    // Consistent winding makes overlapping strips one flat filled surface.
    const area=polygon.reduce((sum,p,j)=>sum+cross(p,polygon[(j+1)%polygon.length]),0);
    if(Math.abs(area)<.1)return;
    const ordered=area<0?[...polygon].reverse():polygon;
    pieces.push(`M ${ordered.map(p=>`${p.x},${p.y}`).join(" L ")} Z`);
  }
  function sideClearance(a,b,normal,nearby,gap) {
    let width=maxHalfWidth;
    const length=Math.hypot(b.x-a.x,b.y-a.y),count=Math.max(1,Math.ceil(length/3));
    for(let j=0;j<=count;j++) {
      const p={x:a.x+(b.x-a.x)*j/count,y:a.y+(b.y-a.y)*j/count};
      for(const[c,d]of nearby) {
        const v={x:d.x-c.x,y:d.y-c.y},q={x:c.x-p.x,y:c.y-p.y},den=cross(normal,v);
        if(Math.abs(den)<.00001)continue;
        const t=cross(q,v)/den,u=cross(q,normal)/den;
        if(t>=0&&u>=0&&u<=1)width=Math.min(width,Math.max(0,t-gap));
      }
    }
    return width;
  }
  function recordEnd(node,left,right,nearby,gap) {
    if(!ends.has(node.id))ends.set(node.id,{node,sections:[],walls:new Set(),gap});
    const end=ends.get(node.id);end.gap=Math.min(end.gap,gap);
    end.sections.push([left,right]);nearby.forEach(w=>end.walls.add(w));
  }
  for(const edge of edgeLayer.querySelectorAll("path,line,polyline")) {
    const vertices=blueprintEdgeVertices(edge,svg);
    if(vertices.length<2){excluded++;continue;}
    const na=nearestNavNode(vertices[0],nodes),nb=nearestNavNode(vertices.at(-1),nodes);
    // Allowlist both ends, rather than guessing purpose from edge length.
    // Room access, unknown destinations, entrances and connector interiors
    // therefore never contribute a strip, including long room-door spurs.
    if(!hallway(na)||!hallway(nb)){excluded++;continue;}
    const points=vertices.map(p=>nearestNavNode(p,nodes)||p);
    let contributed=false;
    for(let j=0;j<points.length-1;j++) {
      const a=points[j],b=points[j+1],dx=b.x-a.x,dy=b.y-a.y,length=Math.hypot(dx,dy);
      if(length<.1)continue;
      const n={x:-dy/length,y:dx/length},margin=maxHalfWidth+wallGap;
      const nearby=walls.filter(([c,d])=>Math.max(c.x,d.x)>=Math.min(a.x,b.x)-margin &&
        Math.min(c.x,d.x)<=Math.max(a.x,b.x)+margin && Math.max(c.y,d.y)>=Math.min(a.y,b.y)-margin &&
        Math.min(c.y,d.y)<=Math.max(a.y,b.y)+margin);
      const clearance=nearby.reduce((best,[c,d])=>Math.min(best,segmentClearance(a,b,c,d)),Infinity);
      // Near a tight door jamb, retain a narrow/asymmetric surface with at
      // least 1.8 native units of clearance (walls have a 1.5-unit half-stroke).
      const gap=Math.min(wallGap,Math.max(1.8,clearance*.82));
      let left=sideClearance(a,b,n,nearby,gap),right=sideClearance(a,b,{x:-n.x,y:-n.y},nearby,gap);
      let polygon;
      for(let attempt=0;attempt<24;attempt++) {
        polygon=[{x:a.x+n.x*left,y:a.y+n.y*left},{x:b.x+n.x*left,y:b.y+n.y*left},
          {x:b.x-n.x*right,y:b.y-n.y*right},{x:a.x-n.x*right,y:a.y-n.y*right}];
        if(safe(polygon,nearby,gap))break;
        left*=.8;right*=.8;polygon=null;
      }
      // If the frozen centerline itself intersects a wall, leave the unsafe
      // section unfilled. Never move its coordinates or hide that uncertainty.
      if(!polygon||left+right<2){excluded++;unsafeEdges.push(edge.id);continue;}
      if(left<maxHalfWidth-.1||right<maxHalfWidth-.1)narrowed++;
      addPolygon(polygon);contributed=true;
      if(a.id)recordEnd(a,polygon[0],polygon[3],nearby,gap);
      if(b.id)recordEnd(b,polygon[1],polygon[2],nearby,gap);
    }
    if(contributed)accepted++;
  }
  // Close only the small wedges between incident strips. Convex, wall-checked
  // triangular joins avoid discs and oversized circular intersections.
  for(const {node,sections,walls:nearby,gap}of ends.values()) {
    if(sections.length<2)continue;
    const corners=sections.flat().sort((a,b)=>Math.atan2(a.y-node.y,a.x-node.x)-Math.atan2(b.y-node.y,b.x-node.x));
    for(let j=0;j<corners.length;j++) {
      const triangle=[{x:node.x,y:node.y},corners[j],corners[(j+1)%corners.length]];
      if(safe(triangle,[...nearby],gap))addPolygon(triangle);
    }
  }
  const group=document.createElementNS(SVG_NS,"g");group.id="campusnav-floor-corridors";
  group.setAttribute("aria-hidden","true");group.dataset.surfaceAlgorithm="F2-wall-checked-polygons";
  group.dataset.acceptedEdges=accepted;group.dataset.excludedEdges=excluded;group.dataset.narrowedSegments=narrowed;
  group.dataset.unsafeSections=[...new Set(unsafeEdges)].join(" ");
  const surface=document.createElementNS(SVG_NS,"path");surface.setAttribute("d",pieces.join(" "));
  surface.setAttribute("class","cn-corridor-surface");group.appendChild(surface);svg.insertBefore(group,wallLayer);
}
function hideTechnicalGraph(svg) {
  svg.querySelectorAll("g").forEach(group=>{
    if (/\bnav[\s_-]*(nodes|edges)|navigation[\s_-]*(nodes|edges)/.test(layerToken(group))) {
      group.classList.add("cn-hide-graph");group.setAttribute("aria-hidden","true");
    }
  });
  svg.querySelectorAll("circle,ellipse,text,path,line").forEach(shape=>{
    if(shape.closest(".cn-hide-graph"))return;
    const id=shape.id||"",text=(shape.textContent||"").trim();
    if(/^(nav[-_]|node[-_]|edge[-_]|C\d+$)/i.test(id) ||
      (shape.localName==="text" && /^(C\d+|NAV[-_].*|NODE[-_].*)$/i.test(text)) ||
      (["circle","ellipse"].includes(shape.localName) &&
       /008000|0093ff|1597e5/i.test((shape.getAttribute("style")||"")+(shape.getAttribute("fill")||"")))) {
      shape.classList.add("cn-hide-graph");shape.setAttribute("aria-hidden","true");
    }
  });
}
function isClosedShape(shape) {
  return shape.localName==="rect" || shape.localName==="polygon" ||
    (shape.localName==="path" && /[zZ]\s*$/.test(shape.getAttribute("d")||""));
}
function containsRootPoint(shape,point,svg) {
  if(!isClosedShape(shape)||!point||typeof shape.isPointInFill!=="function")return false;
  const matrix=shape.getCTM()?.inverse().multiply(svg.getCTM());
  return Boolean(matrix && shape.isPointInFill(new DOMPoint(point.x,point.y).matrixTransform(matrix)));
}
function containedShape(label,shapes,svg,anchor=null) {
  const box=label.getBBox();
  const point=anchor||pointInRoot(label,box.x+box.width/2,box.y+box.height/2,svg);
  const candidates=shapes.filter(shape=>containsRootPoint(shape,point,svg));
  return candidates.length===1?candidates[0]:null;
}
function colorInfrastructure(svg,floorId) {
  const layer=findLayer(svg,/map[\s_-]*infrastructure/);if(!layer)return;
  layer.classList.add("cn-infrastructure-outline");
  const shapes=[...layer.querySelectorAll("rect,path,polygon")].filter(isClosedShape);
  const nodes=collectNavNodes(findLayer(svg,/nav[\s_-]*nodes/),floorId,svg);
  layer.querySelectorAll("text").forEach(label=>{
    const match=label.textContent.trim().match(/^(LIFT|STAIRS?)(\d+)/i);if(!match)return;
    const kind=/lift/i.test(match[1])?"lift":"stair",number=match[2];
    const node=nodes.find(n=>new RegExp(`^${kind==="lift"?"LIFT":"STAIRS?"}${number}(?:-|$)`,"i").test(n.id));
    const shape=containedShape(label,shapes,svg,node)||containedShape(label,shapes,svg);
    if(shape)shape.classList.add("cn-facility",`cn-space-${kind}`);
    label.textContent=`${kind==="lift"?"Lift":"Stair"} ${number}`;
    label.classList.add("cn-facility-label",`cn-label-${kind}`);
  });
  // Older maps have closed facility outlines without printed facility labels.
  // An explicitly identified connector inside exactly one existing outline
  // can label and color that outline without inventing room geometry.
  const labeled = new Set([...layer.querySelectorAll("text")].map(label=>label.textContent.trim()));
  for (const node of nodes) {
    const match=node.id.match(/^(LIFT|STAIRS?)(\d+)(?:-|$)/i);
    if (!match) continue;
    const kind=/lift/i.test(match[1])?"lift":"stair";
    const name=`${kind==="lift"?"Lift":"Stair"} ${match[2]}`;
    if (labeled.has(name)) continue;
    const candidates=shapes.filter(shape=>containsRootPoint(shape,node,svg));
    if (candidates.length!==1) continue;
    const shape=candidates[0];
    shape.classList.add("cn-facility",`cn-space-${kind}`);
    const b=shape.getBBox(),p=pointInRoot(shape,b.x+b.width/2,b.y+b.height/2,svg);
    const label=document.createElementNS(SVG_NS,"text");
    const local=new DOMPoint(p.x,p.y).matrixTransform(layer.getCTM().inverse().multiply(svg.getCTM()));
    label.setAttribute("x",local.x); label.setAttribute("y",local.y);
    label.setAttribute("text-anchor","middle");
    label.style.fontSize=`${Math.min(getViewBox(svg).w,getViewBox(svg).h)*.008}px`;
    label.classList.add("cn-facility-label",`cn-label-${kind}`);
    label.textContent=name; layer.appendChild(label); labeled.add(name);
  }
}
function semanticRoomClass(location) {
  const hay=normalizeText(`${location?.type||""} ${location?.name||""}`);
  if(/toilet|bathroom|washroom|restroom|\bwc\b/.test(hay))return "bathroom";
  if(/research|laboratory|\blab\b/.test(hay))return "lab";
  if(/faculty|office|admin|staff/.test(hay))return "office";
  if(/electrical|utility|store|storage|server|service|mechanical/.test(hay))return "utility";
  if(/courtyard|open area|open.to.sky|garden|atrium/.test(hay))return "courtyard";
  if(/classroom|\broom\b|lecture/.test(hay))return "classroom";
  return "unknown";
}
function semanticTypeLabel(kind) {
  return {classroom:"Classroom",lab:"Lab / research",office:"Faculty / office",
    bathroom:"Bathroom",utility:"Utility",courtyard:"Open area"}[kind]||"";
}
function locationKey(code) {
  return String(code).toUpperCase().replace(/^G-(\d+)/,"G$1");
}
function colorRoomLabels(svg,floorId) {
  const layer=findLayer(svg,/map[\s_-]*rooms/);if(!layer)return;
  const locations=new Map((state.locationsByFloor.get(floorId)||[]).map(item=>[locationKey(item.code),item]));
  const shapes=[...layer.querySelectorAll("rect,path,polygon")].filter(isClosedShape),labels=[...layer.querySelectorAll("text")];
  for(const label of labels) {
    const raw=label.textContent.trim();
    const location=locations.get(locationKey(raw))||{name:raw,type:""};
    const kind=semanticRoomClass(location),shape=containedShape(label,shapes,svg);
    if(shape && labels.filter(other=>{
      const b=other.getBBox();
      return containsRootPoint(shape,pointInRoot(other,b.x+b.width/2,b.y+b.height/2,svg),svg);
    }).length===1)shape.classList.add("cn-facility",`cn-space-${kind}`);
    label.classList.add("cn-space-label",`cn-label-${kind}`);
    label.setAttribute("aria-label",`${raw} · ${location.name||semanticTypeLabel(kind)}`);
    const title=document.createElementNS(SVG_NS,"tspan");
    title.textContent=kind==="bathroom"?`🚻 ${raw}`:raw;
    label.replaceChildren(title);
    const type=semanticTypeLabel(kind);
    if(type) {
      const subtitle=document.createElementNS(SVG_NS,"tspan");
      subtitle.setAttribute("x",label.getAttribute("x")||"0");
      subtitle.setAttribute("dy","1.3em");subtitle.setAttribute("class","cn-label-type");
      subtitle.textContent=type;label.appendChild(subtitle);
    }
  }
}
function raiseMapLabels(svg) {
  const group=document.createElementNS(SVG_NS,"g");group.id="campusnav-map-labels";
  for(const layer of svg.querySelectorAll("g")) {
    if(!/map[\s_-]*(rooms|infrastructure)/.test(layerToken(layer)))continue;
    for(const label of [...layer.querySelectorAll("text")]) {
      const clone=label.cloneNode(true);clone.removeAttribute("id");
      clone.dataset.mapLabel="true";
      clone.dataset.sourceFont=String(parseFloat(getComputedStyle(label).fontSize)||12);
      const wrapper=document.createElementNS(SVG_NS,"g");
      const m=svg.getCTM().inverse().multiply(label.parentNode.getCTM());
      wrapper.setAttribute("transform",`matrix(${m.a} ${m.b} ${m.c} ${m.d} ${m.e} ${m.f})`);
      const x=Number(label.getAttribute("x"))||0,y=Number(label.getAttribute("y"))||0;
      clone.setAttribute("transform",`${clone.getAttribute("transform")||""} rotate(-90 ${x} ${y})`);
      wrapper.appendChild(clone);group.appendChild(wrapper);
      label.classList.add("cn-source-label");label.setAttribute("aria-hidden","true");
    }
  }
  group.setAttribute("pointer-events","none");svg.appendChild(group);
}
function mapContentViewBox(svg,fallback) {
  const wall=findLayer(svg,/map[\s_-]*walls/);if(!wall)return fallback;
  const b=wall.getBBox(),m=svg.getCTM().inverse().multiply(wall.getCTM());
  const corners=[[b.x,b.y],[b.x+b.width,b.y],[b.x,b.y+b.height],[b.x+b.width,b.y+b.height]]
    .map(([x,y])=>new DOMPoint(x,y).matrixTransform(m));
  const xs=corners.map(p=>p.x),ys=corners.map(p=>p.y),x=Math.min(...xs),y=Math.min(...ys);
  const w=Math.max(...xs)-x,h=Math.max(...ys)-y,pad=Math.max(w,h)*.075;
  return {x:x-pad,y:y-pad,w:w+pad*2,h:h+pad*2};
}

function drawRouteOverlay() {
  const svg = state.currentSvg;
  if (!svg) return;
  svg.querySelector("#campusnav-route-overlay")?.remove();
  if (!state.route) return;

  const floor = state.selectedFloor;
  const allPoints = state.floorRouteIndexes[floor] || [];
  if (!allPoints.length) return;

  const currentCheckpoint = state.route.checkpoints?.[state.currentCheckpointIndex];
  const currentPathIndex = currentCheckpoint?.path_index ?? 0;
  const remaining = allPoints.filter((point) => point.globalIndex === -1 || point.globalIndex >= currentPathIndex);
  if (!remaining.length) return;

  const floorCheckpoints = (state.route.checkpoints || []).filter(
    (cp) => cp.floor_id === floor && cp.path_index >= currentPathIndex
  );
  // Every point is retained, including tiny bends and repeated coordinates.
  const group=document.createElementNS(SVG_NS,"g");
  group.id="campusnav-route-overlay";
  if(remaining.length>=2) {
    const points=remaining.map(p=>`${p.x},${p.y}`).join(" ");
    for(const cls of ["cn-route-halo","cn-route-line"]) {
      const line=document.createElementNS(SVG_NS,"polyline");
      line.setAttribute("points",points);line.setAttribute("class",cls);
      line.setAttribute("pointer-events","none");group.appendChild(line);
    }
  }
  const arrows=document.createElementNS(SVG_NS,"g");
  arrows.id="campusnav-route-arrows";group.appendChild(arrows);

  const markers=document.createElementNS(SVG_NS,"g");
  markers.id="campusnav-route-markers";group.appendChild(markers);
  if(floor!=="F2")floorCheckpoints.forEach((cp) => {
    const index = state.route.checkpoints.indexOf(cp);
    drawCheckpoint(markers, cp, index);
  });

  const parent=state.rotationGroup||svg;
  parent.insertBefore(group,parent.querySelector("#campusnav-map-labels"));
  updateOverlayScale();
}

function drawDirectionArrows(group, points, visibleMarkers=[]) {
  if (points.length < 2) return;
  if(state.selectedFloor==="F2") {
    const units=getUnitsPerPixel(),length=7*units,width=5*units,spacing=105*units;
    let travelled=0,next=spacing*.55;
    for(let i=0;i<points.length-1;i++) {
      const a=points[i],b=points[i+1],dx=b.x-a.x,dy=b.y-a.y,segment=Math.hypot(dx,dy);
      if(segment<.001)continue;
      const ux=dx/segment,uy=dy/segment;
      while(next<=travelled+segment) {
        const position=next-travelled;next+=spacing;
        // Keep each complete arrow on a single segment, away from bends and
        // visible markers. Its symmetry axis lies exactly on that segment.
        if(position<14*units||segment-position<14*units)continue;
        const x=a.x+ux*position,y=a.y+uy*position;
        if(visibleMarkers.some(p=>Math.hypot(p.x-x,p.y-y)<16*units))continue;
        const tip={x:x+ux*length*.7,y:y+uy*length*.7};
        const base={x:x-ux*length*.55,y:y-uy*length*.55};
        const arrow=document.createElementNS(SVG_NS,"polygon");
        arrow.setAttribute("points",`${tip.x},${tip.y} ${base.x-uy*width/2},${base.y+ux*width/2} ${base.x+uy*width/2},${base.y-ux*width/2}`);
        arrow.setAttribute("class","cn-route-arrowhead");
        arrow.dataset.centerX=x;arrow.dataset.centerY=y;arrow.dataset.segmentIndex=i;
        group.appendChild(arrow);
      }
      travelled+=segment;
    }
    // At a compact full-floor view the regularly spaced candidates can all
    // land near bends. Use one eligible segment midpoint as a clean fallback.
    if(!group.childElementCount) {
      const segments=points.slice(0,-1).map((a,i)=>({a,b:points[i+1],i,
        size:Math.hypot(points[i+1].x-a.x,points[i+1].y-a.y)})).sort((a,b)=>b.size-a.size);
      for(const {a,b,i,size}of segments) {
        if(size<32*units)continue;
        const x=(a.x+b.x)/2,y=(a.y+b.y)/2;
        if(visibleMarkers.some(p=>Math.hypot(p.x-x,p.y-y)<16*units))continue;
        const ux=(b.x-a.x)/size,uy=(b.y-a.y)/size;
        const tip={x:x+ux*length*.7,y:y+uy*length*.7},base={x:x-ux*length*.55,y:y-uy*length*.55};
        const arrow=document.createElementNS(SVG_NS,"polygon");
        arrow.setAttribute("points",`${tip.x},${tip.y} ${base.x-uy*width/2},${base.y+ux*width/2} ${base.x+uy*width/2},${base.y-ux*width/2}`);
        arrow.setAttribute("class","cn-route-arrowhead");
        arrow.dataset.centerX=x;arrow.dataset.centerY=y;arrow.dataset.segmentIndex=i;
        group.appendChild(arrow);break;
      }
    }
    return;
  }

  // Draw explicit SVG triangles rather than relying only on marker-end.
  // This stays visible in imported Inkscape SVGs and after the shared
  // 90° clockwise transform.
  const unitsPerPx = getUnitsPerPixel();
  const desiredSpacing = 105 * unitsPerPx;
  const arrowLength = 7 * unitsPerPx;
  const arrowWidth = 5 * unitsPerPx;
  let distanceSinceArrow = desiredSpacing * 0.45;

  for (let i = 0; i < points.length - 1; i++) {
    const a = points[i];
    const b = points[i + 1];
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    const segment = Math.hypot(dx, dy);
    if (segment <= 0.001) continue;

    const ux = dx / segment;
    const uy = dy / segment;
    let position = Math.max(0, desiredSpacing - distanceSinceArrow);

    while (position < segment - arrowLength * 1.3) {
      const cx = a.x + ux * position;
      const cy = a.y + uy * position;
      const tipX = cx + ux * arrowLength * 0.7;
      const tipY = cy + uy * arrowLength * 0.7;
      const baseX = cx - ux * arrowLength * 0.55;
      const baseY = cy - uy * arrowLength * 0.55;
      const px = -uy * arrowWidth * 0.5;
      const py = ux * arrowWidth * 0.5;

      const arrow = document.createElementNS(SVG_NS, "polygon");
      arrow.setAttribute(
        "points",
        `${tipX},${tipY} ${baseX + px},${baseY + py} ${baseX - px},${baseY - py}`
      );
      arrow.setAttribute("class", "cn-route-arrowhead");
      group.appendChild(arrow);

      position += desiredSpacing;
    }

    distanceSinceArrow = segment - Math.max(0, position - desiredSpacing);
    if (distanceSinceArrow > desiredSpacing) distanceSinceArrow %= desiredSpacing;
  }
}

function drawCheckpoint(group, cp, index) {
  const isCurrent = index === state.currentCheckpointIndex;
  const isDestination = index === state.route.checkpoints.length - 1;

  const hit = document.createElementNS(SVG_NS, "circle");
  hit.setAttribute("cx", cp.x);
  hit.setAttribute("cy", cp.y);
  hit.setAttribute("class", "cn-checkpoint-hit");
  hit.dataset.radiusPx = "17";
  hit.dataset.checkpointIndex = String(index);
  hit.addEventListener("click", () => reachCheckpoint(index));
  group.appendChild(hit);

  const circle = document.createElementNS(SVG_NS, "circle");
  circle.setAttribute("cx", cp.x);
  circle.setAttribute("cy", cp.y);
  circle.dataset.radiusPx = state.selectedFloor==="F2"
    ? (isCurrent?"6":isDestination?"5.5":"4")
    : (isCurrent ? "7" : isDestination ? "6" : "5");
  circle.setAttribute("role","button");
  circle.setAttribute("tabindex","0");
  circle.setAttribute("aria-label",`Point ${cp.checkpoint}: ${friendlyCode(cp.label)}`);
  circle.addEventListener("keydown",event=>{
    if(event.key==="Enter"||event.key===" ") {event.preventDefault();reachCheckpoint(index);}
  });
  circle.dataset.checkpointIndex = String(index);
  circle.setAttribute(
    "class",
    `${isCurrent ? "cn-checkpoint-current" : isDestination ? "cn-checkpoint-destination" : "cn-checkpoint-dot"}${index === 0 ? " cn-route-start" : ""}`
  );
  circle.addEventListener("click", () => reachCheckpoint(index));
  group.appendChild(circle);

  const number = document.createElementNS(SVG_NS, "text");
  number.setAttribute("x", cp.x);
  number.setAttribute("y", cp.y);
  number.dataset.fontPx = "6.5";
  number.setAttribute("transform", `rotate(-90 ${cp.x} ${cp.y})`);
  number.setAttribute(
    "class",
    `cn-checkpoint-number${isCurrent ? " current" : ""}${isDestination ? " destination" : ""}`
  );
  number.textContent = String(cp.checkpoint);
  group.appendChild(number);

  if (isCurrent) {
    const label = document.createElementNS(SVG_NS, "text");
    label.setAttribute("x", cp.x);
    label.setAttribute("y", cp.y);
    label.dataset.fontPx = "10";
    label.dataset.offsetXPx = "13";
    label.dataset.offsetYPx = "-12";
    label.dataset.anchorX = String(cp.x);
    label.dataset.anchorY = String(cp.y);
    label.setAttribute("class", "cn-location-label");
    label.textContent = "You";
    label.dataset.counterRotate = "true";
    group.appendChild(label);
  }
}

function drawF2RouteMarkers(group,points,units) {
  const checkpoints=state.route?.checkpoints||[],candidates=new Map();
  const current=checkpoints[state.currentCheckpointIndex]?.path_index??0;
  const byIndex=new Map(points.map(p=>[p.globalIndex,p]));
  for(let index=0;index<checkpoints.length;index++) {
    const cp=checkpoints[index];
    if(cp.floor_id!=="F2"||cp.path_index<current)continue;
    const vertex=byIndex.get(cp.path_index);
    if(!vertex)continue;
    // Markers and polyline consume the very same original route vertex.
    const priority=index===state.currentCheckpointIndex?1000:index===checkpoints.length-1?900:
      index===state.currentCheckpointIndex+1?400:100;
    candidates.set(vertex.globalIndex,{...vertex,cp,index,priority});
  }
  for(let i=1;i<points.length-1;i++) {
    const p=points[i];let before=i-1,after=i+1;
    while(before>=0&&Math.hypot(points[before].x-p.x,points[before].y-p.y)<.001)before--;
    while(after<points.length&&Math.hypot(points[after].x-p.x,points[after].y-p.y)<.001)after++;
    if(before<0||after>=points.length)continue;
    const a=points[before],b=points[after],ux=p.x-a.x,uy=p.y-a.y,vx=b.x-p.x,vy=b.y-p.y;
    const angle=Math.acos(Math.max(-1,Math.min(1,(ux*vx+uy*vy)/(Math.hypot(ux,uy)*Math.hypot(vx,vy)))))*180/Math.PI;
    if(angle<35)continue;
    const candidate=candidates.get(p.globalIndex)||{...p};
    candidate.turn=true;candidate.priority=Math.max(candidate.priority||0,600+angle);
    candidates.set(p.globalIndex,candidate);
  }
  const displayed=[],spacing=22*units;
  for(const candidate of [...candidates.values()].sort((a,b)=>b.priority-a.priority||a.globalIndex-b.globalIndex)) {
    if(displayed.some(p=>Math.hypot(p.x-candidate.x,p.y-candidate.y)<spacing))continue;
    displayed.push(candidate);
  }
  const focused=document.activeElement?.dataset?.checkpointIndex;
  group.replaceChildren();group.dataset.minimumSpacingPx="22";
  for(const marker of displayed.sort((a,b)=>a.globalIndex-b.globalIndex)) {
    if(marker.cp) {
      drawCheckpoint(group,{...marker.cp,x:marker.x,y:marker.y},marker.index);
      const circle=group.querySelector(`circle[data-checkpoint-index="${marker.index}"]:not(.cn-checkpoint-hit)`);
      if(circle)circle.dataset.routeIndex=marker.globalIndex;
      if(marker.turn&&circle)circle.dataset.turn="true";
    } else {
      const dot=document.createElementNS(SVG_NS,"circle");
      dot.setAttribute("cx",marker.x);dot.setAttribute("cy",marker.y);
      dot.setAttribute("class","cn-route-turn");dot.setAttribute("aria-hidden","true");
      dot.dataset.radiusPx="4";dot.dataset.routeIndex=marker.globalIndex;dot.dataset.turn="true";
      group.appendChild(dot);
    }
  }
  if(focused!==undefined)group.querySelector(`circle[role="button"][data-checkpoint-index="${focused}"]`)?.focus({preventScroll:true});
  return displayed;
}

function updateOverlayScale() {
  const svg = state.currentSvg;
  if (!svg) return;
  const unitsPerPx = getUnitsPerPixel();
  const current=state.route?.checkpoints?.[state.currentCheckpointIndex]?.path_index??0;
  const points=(state.floorRouteIndexes[state.selectedFloor]||[]).filter(p=>p.globalIndex===-1||p.globalIndex>=current);
  const markers=svg.querySelector("#campusnav-route-markers");
  const displayed=markers&&state.selectedFloor==="F2" ? drawF2RouteMarkers(markers,points,unitsPerPx):[];

  svg.querySelectorAll("#campusnav-route-overlay circle[data-radius-px]").forEach((circle) => {
    circle.setAttribute("r", Number(circle.dataset.radiusPx) * unitsPerPx);
  });
  svg.querySelectorAll("#campusnav-route-overlay text[data-font-px]").forEach((text) => {
    text.setAttribute("font-size", Number(text.dataset.fontPx) * unitsPerPx);
    if (text.dataset.anchorX) {
      const x = Number(text.dataset.anchorX) + Number(text.dataset.offsetXPx || 0) * unitsPerPx;
      const y = Number(text.dataset.anchorY) + Number(text.dataset.offsetYPx || 0) * unitsPerPx;
      text.setAttribute("x", x);
      text.setAttribute("y", y);
      if (text.dataset.counterRotate) text.setAttribute("transform", `rotate(-90 ${x} ${y})`);
    }
  });
  svg.querySelectorAll("[data-map-label]").forEach(label=>{
    const m=label.getScreenCTM();
    const scale=m?Math.hypot(m.a,m.b):0;
    if(!scale)return;
    const original=Number(label.dataset.sourceFont);
    const px=Math.max(9,Math.min(13,original*scale));
    label.style.setProperty("font-size",`${px/scale}px`,"important");
  });
  const arrows=svg.querySelector("#campusnav-route-arrows");
  if(arrows) {
    arrows.replaceChildren();
    drawDirectionArrows(arrows,points,displayed);
  }
}

function getUnitsPerPixel() {
  if (!state.currentSvg || !state.viewBox) return 1;
  const rect = state.currentSvg.getBoundingClientRect();
  if (!rect.width || !rect.height) return 1;
  return Math.max(state.viewBox.w / rect.width, state.viewBox.h / rect.height);
}

function getViewBox(svg) {
  const raw = svg.getAttribute("viewBox");
  if (raw) {
    const values = raw.trim().split(/[\s,]+/).map(Number);
    if (values.length === 4 && values.every(Number.isFinite)) {
      return { x: values[0], y: values[1], w: values[2], h: values[3] };
    }
  }
  const width = Number(svg.getAttribute("width")) || 1000;
  const height = Number(svg.getAttribute("height")) || 1400;
  return { x: 0, y: 0, w: width, h: height };
}

function applyViewBox() {
  if (!state.currentSvg || !state.viewBox) return;
  const v = state.viewBox;
  state.currentSvg.setAttribute("viewBox", `${v.x} ${v.y} ${v.w} ${v.h}`);
  requestAnimationFrame(updateOverlayScale);
}

function fitMap() {
  if (!state.originalViewBox) return;
  state.viewBox = { ...state.originalViewBox };
  applyViewBox();
}

function zoomMap(factor,clientX=null,clientY=null) {
  if(!state.viewBox||!state.originalViewBox||!state.currentSvg)return;
  const svg=state.currentSvg,v=state.viewBox;
  const point=clientX==null?{x:v.x+v.w/2,y:v.y+v.h/2}:
    new DOMPoint(clientX,clientY).matrixTransform(svg.getScreenCTM().inverse());
  const px=(point.x-v.x)/v.w,py=(point.y-v.y)/v.h,w=v.w*factor,h=v.h*factor;
  if(w<state.originalViewBox.w/7||w>state.originalViewBox.w*1.4)return;
  state.viewBox={x:point.x-px*w,y:point.y-py*h,w,h};applyViewBox();
}
function focusRemainingRoute(cp) {
  if(!cp||!state.originalViewBox)return;
  const current=state.route?.checkpoints?.[state.currentCheckpointIndex]?.path_index??0;
  const points=(state.floorRouteIndexes[state.selectedFloor]||[]).filter(p=>p.globalIndex>=current);
  const anchor=sourcePointToDisplay(cp.x,cp.y);
  const following=points.filter(p=>p.globalIndex>=cp.path_index).slice(0,5).map(p=>sourcePointToDisplay(p.x,p.y));
  const xs=[anchor.x,...following.map(p=>p.x)],ys=[anchor.y,...following.map(p=>p.y)],base=state.originalViewBox;
  const w=Math.min(base.w,Math.max(base.w/2.7,(Math.max(...xs)-Math.min(...xs))*1.6));
  const h=Math.min(base.h,Math.max(base.h/2.7,(Math.max(...ys)-Math.min(...ys))*1.6));
  state.viewBox={x:(Math.min(...xs)+Math.max(...xs)-w)/2,y:(Math.min(...ys)+Math.max(...ys)-h)/2,w,h};applyViewBox();
}

function centerOnCheckpoint(cp) {
  if (!cp || !state.originalViewBox) return;
  const displayPoint = sourcePointToDisplay(cp.x, cp.y);
  const zoom = 2.55;
  const w = state.originalViewBox.w / zoom;
  const h = state.originalViewBox.h / zoom;
  state.viewBox = {
    x: displayPoint.x - w / 2,
    y: displayPoint.y - h / 2,
    w,
    h,
  };
  applyViewBox();
}

function panStart(event) {
  if (!state.currentSvg || !state.viewBox) return;
  if (event.target.closest?.("button, [data-checkpoint-index]")) return;
  state.dragging = true;
  state.dragStart = {
    clientX: event.clientX,
    clientY: event.clientY,
    viewBox: { ...state.viewBox },
  };
  els.mapViewport.setPointerCapture?.(event.pointerId);
}

function panMove(event) {
  if (!state.dragging || !state.dragStart || !state.currentSvg) return;
  const rect = state.currentSvg.getBoundingClientRect();
  if (!rect.width || !rect.height) return;
  const units=Math.max(state.dragStart.viewBox.w/rect.width,state.dragStart.viewBox.h/rect.height);
  const dx=(event.clientX-state.dragStart.clientX)*units;
  const dy=(event.clientY-state.dragStart.clientY)*units;
  state.viewBox = {
    ...state.dragStart.viewBox,
    x: state.dragStart.viewBox.x - dx,
    y: state.dragStart.viewBox.y - dy,
  };
  applyViewBox();
}

function panEnd(event) {
  state.dragging = false;
  state.dragStart = null;
  if (els.mapViewport.hasPointerCapture?.(event.pointerId)) els.mapViewport.releasePointerCapture(event.pointerId);
}

function openBlockedDialog() {
  els.blockedDialog.querySelectorAll(".blocked-grid input").forEach((input) => {
    input.checked = state.blocked.has(input.value);
  });
  els.blockedDialog.showModal();
}

function routingCodeForCheckpoint(cp) {
  if (!cp) return "";
  const candidates = state.floorRouteIndexes?.[cp.floor_id] || [];
  const match = candidates.find((point) => point.globalIndex === cp.path_index);
  return match?.original_node_id || cp.node_id;
}

async function rerouteFromCurrentCheckpoint() {
  if (!state.route || !state.lastPlan) return;
  const selected = [...els.blockedDialog.querySelectorAll(".blocked-grid input:checked")].map((input) => input.value);
  if (!selected.length) {
    showToast("Choose at least one blocked connector");
    return;
  }
  selected.forEach((item) => state.blocked.add(item));
  renderBlockedStatus();
  const cp = state.route.checkpoints[state.currentCheckpointIndex];
  els.blockedDialog.close();

  await planRoute({
    start: {
      kind: "location",
      floor_id: cp.floor_id,
      code: routingCodeForCheckpoint(cp),
      name: cp.label,
      type: "checkpoint",
    },
    destination: state.lastPlan.destination,
    mode: state.lastPlan.mode,
    blocked: [...state.blocked],
  });
  showToast("Alternate route calculated from your current point");
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

boot();
